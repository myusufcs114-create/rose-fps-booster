# Minecraft AI Assistant — Fabric 26.1

A lightweight client-side AI-style companion for Minecraft 26.1.

## Requirements

- Minecraft 26.1
- Fabric Loader 0.19.1 or newer in the 0.19.x line
- Fabric API for 26.1
- Java 25

## Features

- Context-aware chat messages while playing solo.
- Survival context: health, hunger, time of day and nearby entities.
- Basic performance monitoring.
- `/ai performance`
- `/ai status`

This first version is intentionally local and does not send game data to an online AI service.

## Build

```bash
./gradlew build
```

The JAR is created in `build/libs/`.

## GitHub Actions

Push this repository to GitHub and run the **Build Mod** workflow. It uses Java 25 and Gradle 9.4.

Minecraft 26.1 switched Fabric's development toolchain to Mojang's official names and requires Java 25; this project follows that model.
