# Minecraft AI Assistant

Client-side Fabric mod for Minecraft 26.1.

## Build requirements

- Minecraft 26.1
- Fabric Loader 0.19.1
- Java 25
- Gradle 9.4.0
- Fabric Loom 1.15.5
- Fabric API 0.144.3+26.1

Minecraft 26.1 uses the non-obfuscated Fabric Loom setup. Dependencies therefore use
`implementation` rather than the older `modImplementation` configuration.

The included GitHub Actions workflow builds the mod and uploads the JAR as an artifact.

## Commands

- `/ai status`
- `/ai performance`
- `/ai quiet`

The assistant can also send context-aware messages while playing.
