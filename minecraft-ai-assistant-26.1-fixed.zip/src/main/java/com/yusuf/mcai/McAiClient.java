package com.yusuf.mcai;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;

import java.util.Locale;
import java.util.Random;

public class McAiClient implements ClientModInitializer {
    private static final Random RANDOM = new Random();
    private static final String TAG = "[AI] ";
    private long lastTalkTick = -1;
    private long lastPerformanceTick = -1;
    private int talkCooldown = 0;
    private int performanceCooldown = 0;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(Minecraft client) {
        if (client.player == null || client.level == null) return;

        long time = client.level.getGameTime();

        if (talkCooldown > 0) talkCooldown--;
        if (performanceCooldown > 0) performanceCooldown--;

        // First greeting shortly after entering a world.
        if (lastTalkTick < 0) {
            lastTalkTick = time;
            talkCooldown = 160;
            say(client, "Aku aktif. Aku bisa menemani, membaca kondisi dunia, dan membantu optimasi performa.");
            return;
        }

        // Context-aware conversation every ~45-90 seconds.
        if (talkCooldown == 0 && time - lastTalkTick >= 900) {
            lastTalkTick = time;
            talkCooldown = 900 + RANDOM.nextInt(900);
            say(client, contextualMessage(client));
        }

        // Quiet performance warning. It never changes settings automatically.
        if (performanceCooldown == 0 && time % 200 == 0) {
            int fps = client.getFps();
            if (fps > 0 && fps < 25) {
                performanceCooldown = 1200;
                say(client, "FPS-ku mendeteksi sekitar " + fps + " FPS. Coba ketik /ai performance untuk analisis.");
            }
        }
    }

    private String contextualMessage(Minecraft client) {
        int hour = (int)((client.level.getDayTime() / 1000L) % 24L);
        int fps = client.getFps();
        int nearby = 0;
        for (Entity entity : client.level.entitiesForRendering()) {
            if (entity.distanceToSqr(client.player) < 24 * 24) nearby++;
        }

        if (client.player.getHealth() <= 6.0f) {
            return "HP-mu tinggal " + String.format(Locale.ROOT, "%.1f", client.player.getHealth())
                    + ". Kita sebaiknya cari tempat aman dulu.";
        }
        if (client.player.getFoodData().getFoodLevel() <= 6) {
            return "Lapar nih. Mau berhenti sebentar buat makan?";
        }
        if (nearby > 80) {
            return "Banyak entity di sekitar (" + nearby + "). Kalau FPS turun, aku bisa bantu cari penyebabnya.";
        }
        if (hour >= 18 || hour < 6) {
            return "Sudah malam. Mau lanjut eksplorasi atau kembali ke tempat aman?";
        }
        if (fps > 0 && fps < 35) {
            return "Aku melihat FPS sekitar " + fps + ". Kalau mau, gunakan /ai performance.";
        }

        String[] messages = {
                "Apa target kita sekarang: mining, membangun, eksplorasi, atau farming?",
                "Aku masih mengamati dunia. Kalau ada masalah performa, panggil aku dengan /ai performance.",
                "Kalau kamu mau, aku bisa menjadi teman survival yang lebih cerewet atau lebih tenang.",
                "Ada sesuatu yang ingin kamu optimalkan sekarang?"
        };
        return messages[RANDOM.nextInt(messages.length)];
    }

    public static void say(Minecraft client, String message) {
        if (client.player != null) {
            client.player.displayClientMessage(Component.literal(TAG + message), false);
        }
    }

    public static void performance(Minecraft client) {
        if (client.player == null || client.level == null) return;

        long used = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        long max = Runtime.getRuntime().maxMemory();
        int fps = client.getFps();

        int nearby = 0;
        for (Entity entity : client.level.entitiesForRendering()) {
            if (entity.distanceToSqr(client.player) < 32 * 32) nearby++;
        }

        int renderDistance = client.options.getEffectiveRenderDistance();

        say(client, "=== Performance Report ===");
        say(client, "FPS: " + fps);
        say(client, "RAM: " + (used / 1024 / 1024) + " MB / " + (max / 1024 / 1024) + " MB");
        say(client, "Render Distance: " + renderDistance + " chunks");
        say(client, "Nearby entities: " + nearby);

        if (fps < 30) {
            say(client, "Saran: turunkan Render Distance dan Entity Distance, lalu cek shader/resource pack.");
        } else if (fps < 60) {
            say(client, "Saran: performa sedang. Turunkan Render Distance beberapa chunk jika ingin FPS lebih stabil.");
        } else {
            say(client, "Performa terlihat cukup baik dari metrik dasar ini.");
        }
    }
}
