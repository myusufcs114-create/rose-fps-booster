package com.yusuf.mcai;

import com.mojang.authlib.GameProfile;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;

import java.util.*;

/**
 * Rose AI Companion v1.3 / Minecraft 26.1.
 *
 * Singleplayer: creates a client-side Rose-model companion and gives it a small
 * task system (follow, observe, gather guidance, chop-in-reach and structure planning).
 * Multiplayer: the companion body/tasks are disabled; Rose remains a chat-only assistant.
 *
 * Important: world-changing automation is deliberately restricted to singleplayer
 * and to normal client interaction APIs. It never sends fake automation packets to
 * a multiplayer server.
 */
public class McAiClient implements ClientModInitializer {
    private static McAiClient INSTANCE;
    private static final Random RANDOM = new Random();
    private static final String TAG = "[Rose] ";
    private static final UUID ROSE_UUID = UUID.fromString("e5beb6d7-19b7-43e4-92bc-ac3cf948f78c");
    private static final int ROSE_ENTITY_ID = -777777;

    private final Deque<String> conversation = new ArrayDeque<>();
    private long lastTalkTick = -1;
    private int talkCooldown;
    private int performanceCooldown;
    private int replyDelay;
    private String pendingReply;
    private String mood = "netral";
    private String lastPlayerMessage = "";

    private RemotePlayer rose;
    private boolean followEnabled = true;
    private String task = "none";
    private int taskCooldown;
    private String taskInfo = "";
    private boolean exploreEnabled = false;
    private Vec3 exploreTarget;
    private int exploreCooldown;
    private int roseAngryTicks;
    private int roseDeathTicks;
    private float roseHealth = 20.0f;
    private int roseHunger = 20;
    private int roseRespawnTicks;
    private int flowerGestureCooldown;
    private boolean roseFriendshipGesture;
    private int shyGestureTicks;
    private int invitationCooldown;
    private String lastLevelId = "";

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        ClientSendMessageEvents.CHAT.register(this::onPlayerChat);
        ClientPreAttackCallback.EVENT.register((client, player, clickCount) -> {
            if (INSTANCE == null || rose == null || !client.hasSingleplayerServer() || clickCount == 0) return false;
            return INSTANCE.handlePreAttack(client);
        });
    }

    private void onPlayerChat(String message) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return;
        String text = message == null ? "" : message.trim();
        if (text.isEmpty()) return;

        boolean singleplayer = client.hasSingleplayerServer();
        String lower = text.toLowerCase(Locale.ROOT);
        boolean addressed = lower.equals("rose") || lower.startsWith("rose ") || lower.startsWith("rose,")
                || lower.startsWith("rose:") || lower.startsWith("@rose")
                || lower.equals("ai") || lower.startsWith("ai ") || lower.startsWith("ai,")
                || lower.startsWith("ai:") || lower.startsWith("@ai") || lower.startsWith("assistant ");
        if (!singleplayer && !addressed) return;

        String clean = removeAddressPrefix(text);
        if (clean.isBlank()) clean = "hai";
        remember(clean);
        mood = detectMood(clean);
        handleSocialIntent(client, clean);
        handleTaskIntent(client, clean);
        pendingReply = answer(client, clean);
        replyDelay = 4;
    }

    private String removeAddressPrefix(String text) {
        String s = text.trim();
        String l = s.toLowerCase(Locale.ROOT);
        String[] prefixes = {"@rose", "rose:", "rose,", "rose ", "@ai", "ai:", "ai,", "ai ", "assistant "};
        for (String prefix : prefixes) if (l.startsWith(prefix)) return s.substring(prefix.length()).trim();
        if (l.equals("rose") || l.equals("ai")) return "";
        return s;
    }

    private void tick(Minecraft client) {
        if (client.player == null || client.level == null) return;
        long time = client.level.getGameTime();
        if (talkCooldown > 0) talkCooldown--;
        if (performanceCooldown > 0) performanceCooldown--;
        if (taskCooldown > 0) taskCooldown--;
        if (exploreCooldown > 0) exploreCooldown--;
        if (roseAngryTicks > 0) roseAngryTicks--;
        if (roseDeathTicks > 0) roseDeathTicks--;
        if (roseRespawnTicks > 0) roseRespawnTicks--;
        if (flowerGestureCooldown > 0) flowerGestureCooldown--;
        if (shyGestureTicks > 0) shyGestureTicks--;
        if (invitationCooldown > 0) invitationCooldown--;

        if (client.hasSingleplayerServer()) {
            ensureRose(client);
            handleDimensionChange(client);
            if (roseRespawnTicks == 0 && rose != null) updateRose(client);
            updateRoseSurvival(client);
            detectFlowerGift(client);
            runTask(client);
            if (rose != null && task.equals("none") && exploreEnabled && roseAngryTicks == 0) runExploration(client);
        } else if (rose != null) {
            removeRose(client);
        }

        if (replyDelay > 0) {
            replyDelay--;
            if (replyDelay == 0 && pendingReply != null) {
                say(client, pendingReply);
                pendingReply = null;
            }
        }

        if (lastTalkTick < 0) {
            lastTalkTick = time;
            talkCooldown = 3000;
            say(client, "Aku Rose. Di singleplayer aku bisa menemanimu sebagai companion Rose, mengikutimu, membaca dunia, dan menjalankan tugas yang kamu minta. Di multiplayer aku tetap chat-only.");
            return;
        }

        if (talkCooldown == 0 && time - lastTalkTick >= 3000) {
            lastTalkTick = time;
            talkCooldown = 3000 + RANDOM.nextInt(3000);
            say(client, contextualMessage(client));
        }

        if (performanceCooldown == 0 && time % 200 == 0) {
            int fps = client.getFps();
            if (fps > 0 && fps < 25) {
                performanceCooldown = 2400;
                say(client, "FPS sedang sekitar " + fps + ". Kalau kamu mau, aku bisa cek performanya.");
            }
        }
    }

    private void handleDimensionChange(Minecraft client) {
        if (client.level == null) return;
        String id = client.level.dimension().identifier().toString();
        if (!lastLevelId.isEmpty() && !lastLevelId.equals(id)) {
            rose = null;
            exploreTarget = null;
            say(client, "Aku ikut pindah dimensi bersamamu. Jangan khawatir, aku tetap akan mengikutimu.");
        }
        lastLevelId = id;
    }

    private void ensureRose(Minecraft client) {
        if (rose != null && rose.level() == client.level && !rose.isRemoved()) return;
        ClientLevel level = client.level;
        GameProfile profile = new GameProfile(ROSE_UUID, "Rose");
        rose = new RoseRemotePlayer(level, profile);
        rose.setPos(client.player.getX() - 2.0, client.player.getY(), client.player.getZ() - 2.0);
        rose.setYRot(client.player.getYRot());
        rose.setXRot(client.player.getXRot());
        rose.setNoGravity(false);
        roseHealth = 20.0f;
        roseHunger = 20;
        roseFriendshipGesture = false;
        lastLevelId = level.dimension().identifier().toString();
        level.addEntity(rose);
    }

    private void removeRose(Minecraft client) {
        if (rose != null && client.level != null) {
            client.level.removeEntity(rose.getId(), Entity.RemovalReason.DISCARDED);
        }
        rose = null;
    }

    /** Client-side survival foundation for the current companion avatar.
     *  This tracks Rose's own health/hunger state and gives her a death/respawn loop.
     *  Full server-authoritative NPC survival (real inventory, crafting, mob combat,
     *  block placement and chest containers) requires converting the companion to a
     *  common/server-side entity in a later architecture step.
     */
    private void updateRoseSurvival(Minecraft client) {
        if (rose == null || client.player == null || roseRespawnTicks > 0) return;

        // Slowly consume hunger while Rose is active.
        if (client.level.getGameTime() % 2400L == 0 && roseHunger > 0) roseHunger--;

        // Nearby hostile mobs make Rose retreat instead of standing still.
        Entity danger = null;
        double best = 10.0 * 10.0;
        for (Entity e : client.level.entitiesForRendering()) {
            if (e == rose || e == client.player || !e.isAlive()) continue;
            String n = e.getType().toString().toLowerCase(Locale.ROOT);
            if (!(n.contains("zombie") || n.contains("skeleton") || n.contains("creeper") ||
                    n.contains("spider") || n.contains("enderman") || n.contains("witch") ||
                    n.contains("phantom") || n.contains("pillager") || n.contains("vindicator") ||
                    n.contains("ravager") || n.contains("warden"))) continue;
            double d = e.distanceToSqr(rose);
            if (d < best) { best = d; danger = e; }
        }
        if (danger != null && roseAngryTicks == 0 && !roseFriendshipGesture) {
            Vec3 away = rose.position().subtract(danger.position());
            if (away.horizontalDistanceSqr() > 0.01) {
                Vec3 target = rose.position().add(away.normalize().scale(4.0));
                groundedNavigate(client, target, 0.13);
            }
        }

        // Hunger recovery is deliberately conservative; Rose can be given food later.
        if (roseHunger <= 0 && client.level.getGameTime() % 80L == 0 && roseHealth > 0) {
            roseHealth = Math.max(0.0f, roseHealth - 0.1f);
        }
        if (roseHealth <= 0.0f && roseRespawnTicks == 0) {
            roseRespawnTicks = 20 * 5;
            roseDeathTicks = 20 * 5;
            if (rose != null) {
                rose.setInvisible(true);
                rose.setDeltaMovement(Vec3.ZERO);
            }
            say(client, "Aku tumbang... 😵 Aku akan respawn sebentar lagi.");
        }
        if (roseRespawnTicks == 1) {
            roseHealth = 20.0f;
            roseHunger = 20;
            if (rose != null) {
                rose.setInvisible(false);
                rose.setPos(client.player.getX() - 2.0, client.player.getY(), client.player.getZ() - 2.0);
            }
            say(client, "Aku sudah hidup lagi. Kita lanjut! ✨");
        }
    }

    /**
     * A flower is treated as a friendly gift, not a romantic interaction.
     * Rose faces the player and performs a small greeting animation.
     */
    private void detectFlowerGift(Minecraft client) {
        if (rose == null || client.player == null || flowerGestureCooldown > 0 || roseRespawnTicks > 0) return;
        if (rose.distanceTo(client.player) > 4.0f) return;
        ItemStack held = client.player.getMainHandItem();
        if (held.isEmpty()) return;
        String name = held.getHoverName().getString().toLowerCase(Locale.ROOT);
        boolean flower = name.contains("flower") || name.contains("bunga") || name.contains("poppy") ||
                name.contains("tulip") || name.contains("orchid") || name.contains("allium") ||
                name.contains("daisy") || name.contains("cornflower") || name.contains("lily") ||
                name.contains("rose");
        if (!flower) return;

        flowerGestureCooldown = 30;
        roseFriendshipGesture = true;
        smoothLookAt(rose, client.player.position().add(0, 1.2, 0), 360.0f);
        rose.swing(InteractionHand.MAIN_HAND);
        say(client, "Bunganya kuterima! 🌸 Terima kasih. *tersenyum dan melambaikan tangan*");
        roseFriendshipGesture = false;
    }

    /**
     * Grounded companion controller. Rose is deliberately kept as a Player avatar,
     * so we cannot attach vanilla MobNavigation directly (that API is built around
     * MobEntity). Instead this controller uses Minecraft's real collision solver
     * plus a small local grid pathfinder and a gravity/jump controller.
     *
     * The important rule is: NEVER move Rose by changing X/Y/Z directly during
     * normal follow. All normal movement goes through move(MoverType.SELF,...),
     * which makes blocks, slopes and ground collision participate.
     */
    private int rosePathCooldown;
    private final Deque<Vec3> rosePath = new ArrayDeque<>();
    private boolean roseJumping;
    private int roseStuckTicks;
    private Vec3 lastRosePosition = Vec3.ZERO;

    private void updateRose(Minecraft client) {
        if (rose == null || client.player == null) return;
        if (roseAngryTicks > 0) {
            runAngryRetreat(client);
            return;
        }
        if (shyGestureTicks > 0) {
            applyGroundPhysics(client, Vec3.ZERO);
            smoothLookAt(rose, client.player.position().add(0, 1.2, 0), 12.0f);
            rose.setYHeadRot(rose.getYRot());
            return;
        }
        if (!followEnabled) {
            applyGroundPhysics(client, Vec3.ZERO);
            return;
        }

        Player p = client.player;
        double distance = rose.distanceTo(p);
        if (distance > 3.0) {
            double angle = Math.toRadians(p.getYRot());
            Vec3 target = new Vec3(
                    p.getX() - Math.sin(angle) * 2.4,
                    p.getY(),
                    p.getZ() - Math.cos(angle) * 2.4
            );
            double speed = distance > 18.0 ? 0.19 : 0.115;
            groundedNavigate(client, target, speed);
        } else {
            rosePath.clear();
            applyGroundPhysics(client, Vec3.ZERO);
            rose.setSprinting(false);
            smoothLookAt(rose, p.position().add(0, 1.2, 0), 18.0f);
        }
        rose.calculateEntityAnimation(true);
    }

    private void groundedNavigate(Minecraft client, Vec3 target, double speed) {
        if (rose == null || client.level == null) return;

        if (rosePathCooldown-- <= 0 || rosePath.isEmpty() || horizontalDistanceTo(rose.position(), target) > 7.0) {
            rosePathCooldown = 8;
            rebuildLocalPath(client, target);
        }

        Vec3 waypoint = rosePath.peekFirst();
        if (waypoint == null) waypoint = target;
        if (horizontalDistanceTo(rose.position(), waypoint) < 0.75) {
            rosePath.pollFirst();
            waypoint = rosePath.peekFirst();
            if (waypoint == null) waypoint = target;
        }

        Vec3 desired = waypoint.subtract(rose.position());
        Vec3 horizontal = new Vec3(desired.x, 0, desired.z);
        if (horizontal.lengthSqr() < 0.0025) {
            applyGroundPhysics(client, Vec3.ZERO);
            return;
        }

        horizontal = horizontal.normalize().scale(speed);
        Vec3 steering = chooseWalkDirection(client, horizontal);
        boolean blocked = steering.lengthSqr() < 0.0001;

        if (blocked && rose.onGround() && canJumpForward(client, horizontal)) {
            roseJumping = true;
        }

        if (roseJumping && rose.onGround()) {
            rose.setDeltaMovement(rose.getDeltaMovement().x, 0.42, rose.getDeltaMovement().z);
            rose.setOnGround(false);
        }

        if (!blocked) {
            applyGroundPhysics(client, steering);
            float yaw = (float) Math.toDegrees(Math.atan2(-steering.x, steering.z));
            rose.setYRot(smoothAngle(rose.getYRot(), yaw, 18.0f));
            rose.setYBodyRot(rose.getYRot());
            rose.setYHeadRot(rose.getYRot());
            rose.setSprinting(speed > 0.15);
        } else {
            applyGroundPhysics(client, Vec3.ZERO);
        }

        if (rose.onGround() && rose.getDeltaMovement().y <= 0.05) roseJumping = false;

        // Stuck detection: rebuild the path instead of teleporting through the obstacle.
        if (rose.position().distanceTo(lastRosePosition) < 0.015) roseStuckTicks++;
        else roseStuckTicks = 0;
        lastRosePosition = rose.position();
        if (roseStuckTicks > 12) {
            rosePath.clear();
            rosePathCooldown = 0;
            roseStuckTicks = 0;
        }
    }

    private void applyGroundPhysics(Minecraft client, Vec3 horizontal) {
        if (rose == null) return;
        Vec3 v = rose.getDeltaMovement();
        double vy = v.y;

        // Real gravity. No no-gravity hovering and no direct Y teleporting.
        if (!rose.onGround()) vy = Math.max(vy - 0.08, -0.65);
        else if (vy < 0) vy = 0;

        Vec3 movement = new Vec3(horizontal.x, vy, horizontal.z);
        rose.setDeltaMovement(movement);
        rose.move(MoverType.SELF, movement);

        // Let collision state, not our code, decide whether Rose is grounded.
        if (rose.onGround() && rose.getDeltaMovement().y < 0) {
            rose.setDeltaMovement(rose.getDeltaMovement().x, 0, rose.getDeltaMovement().z);
        }
    }

    private Vec3 chooseWalkDirection(Minecraft client, Vec3 desired) {
        if (canMove(client, desired.x, 0, desired.z)) return desired;

        // Try small steering angles first: this makes Rose slide around trees,
        // corners and other obstacles instead of stopping or flying through them.
        double base = Math.atan2(desired.z, desired.x);
        double[] angles = {Math.PI / 4, -Math.PI / 4, Math.PI / 2, -Math.PI / 2,
                3 * Math.PI / 4, -3 * Math.PI / 4, Math.PI};
        for (double offset : angles) {
            double a = base + offset;
            Vec3 candidate = new Vec3(Math.cos(a), 0, Math.sin(a)).scale(desired.horizontalDistance());
            if (canMove(client, candidate.x, 0, candidate.z)) return candidate;
        }
        return Vec3.ZERO;
    }

    private boolean canMove(Minecraft client, double dx, double dy, double dz) {
        if (rose == null || client.level == null) return false;
        AABB box = rose.getBoundingBox().move(dx, dy, dz);
        return client.level.noCollision(rose, box);
    }

    private boolean canJumpForward(Minecraft client, Vec3 horizontal) {
        if (rose == null || client.level == null || !rose.onGround()) return false;
        double len = Math.max(0.001, horizontal.horizontalDistance());
        double nx = horizontal.x / len;
        double nz = horizontal.z / len;
        // One-block obstacle in front + enough headroom above it.
        return !canMove(client, nx * 0.45, 0, nz * 0.45)
                && canMove(client, nx * 0.45, 1.05, nz * 0.45)
                && canMove(client, nx * 0.45, 1.55, nz * 0.45);
    }

    /** Small local A* grid around Rose. Nodes are grounded positions only. */
    private void rebuildLocalPath(Minecraft client, Vec3 target) {
        rosePath.clear();
        if (rose == null || client.level == null) return;

        BlockPos start = rose.blockPosition();
        BlockPos goal = new BlockPos((int)Math.floor(target.x), (int)Math.floor(target.y), (int)Math.floor(target.z));
        NodeKey startKey = findWalkableNode(client, start, start);
        NodeKey goalKey = findWalkableNode(client, goal, start);
        if (startKey == null || goalKey == null) return;

        PriorityQueue<PathNode> open = new PriorityQueue<>(Comparator.comparingDouble(n -> n.f));
        Map<NodeKey, PathNode> all = new HashMap<>();
        Set<NodeKey> closed = new HashSet<>();
        PathNode first = new PathNode(startKey, null, 0, heuristic(startKey, goalKey));
        open.add(first);
        all.put(startKey, first);

        int expanded = 0;
        while (!open.isEmpty() && expanded++ < 650) {
            PathNode current = open.poll();
            if (!closed.add(current.key)) continue;
            if (current.key.equals(goalKey)) {
                ArrayList<Vec3> reversed = new ArrayList<>();
                PathNode n = current;
                while (n != null) {
                    if (!n.key.equals(startKey)) reversed.add(centerOf(n.key));
                    n = n.parent;
                }
                Collections.reverse(reversed);
                rosePath.addAll(reversed);
                return;
            }

            for (int[] dir : new int[][]{{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}}) {
                NodeKey next = findWalkableNode(client,
                        new BlockPos(current.key.x + dir[0], current.key.y, current.key.z + dir[1]),
                        start);
                if (next == null || closed.contains(next)) continue;
                double step = (dir[0] != 0 && dir[1] != 0) ? 1.414 : 1.0;
                if (next.y != current.key.y) step += 0.35;
                double g = current.g + step;
                PathNode old = all.get(next);
                if (old == null || g < old.g) {
                    PathNode nn = new PathNode(next, current, g, g + heuristic(next, goalKey));
                    all.put(next, nn);
                    open.add(nn);
                }
            }
        }
    }

    private NodeKey findWalkableNode(Minecraft client, BlockPos desired, BlockPos origin) {
        int maxDelta = 2;
        for (int dy = -maxDelta; dy <= maxDelta; dy++) {
            int y = desired.getY() + dy;
            if (isStandable(client, desired.getX(), y, desired.getZ())) {
                return new NodeKey(desired.getX(), y, desired.getZ());
            }
        }
        return null;
    }

    private boolean isStandable(Minecraft client, int x, int y, int z) {
        if (rose == null || client.level == null) return false;
        double px = x + 0.5;
        double py = y;
        double pz = z + 0.5;
        AABB base = rose.getBoundingBox();
        double dx = px - (base.minX + base.maxX) * 0.5;
        double dz = pz - (base.minZ + base.maxZ) * 0.5;
        double dy = py - base.minY;
        AABB at = base.move(dx, dy, dz);
        if (!client.level.noCollision(rose, at)) return false;
        // Must have support under the feet; prevents path nodes floating over caves.
        return !client.level.noCollision(rose, at.move(0, -0.12, 0));
    }

    private double heuristic(NodeKey a, NodeKey b) {
        return Math.sqrt((a.x-b.x)*(a.x-b.x) + (a.z-b.z)*(a.z-b.z)) + Math.abs(a.y-b.y) * 0.5;
    }

    private Vec3 centerOf(NodeKey n) { return new Vec3(n.x + 0.5, n.y, n.z + 0.5); }

    private record NodeKey(int x, int y, int z) {}
    private static final class PathNode {
        final NodeKey key;
        final PathNode parent;
        final double g;
        final double f;
        PathNode(NodeKey key, PathNode parent, double g, double f) {
            this.key = key; this.parent = parent; this.g = g; this.f = f;
        }
    }

    private double horizontalDistanceTo(Vec3 a, Vec3 b) {
        double dx = a.x - b.x, dz = a.z - b.z;
        return Math.sqrt(dx * dx + dz * dz);
    }

    private void smoothLookAt(RemotePlayer entity, Vec3 target, float maxTurn) {
        Vec3 d = target.subtract(entity.getEyePosition());
        float yaw = (float)Math.toDegrees(Math.atan2(-d.x, d.z));
        float pitch = (float)-Math.toDegrees(Math.atan2(d.y, Math.sqrt(d.x*d.x+d.z*d.z)));
        entity.setYRot(smoothAngle(entity.getYRot(), yaw, maxTurn));
        entity.setYHeadRot(entity.getYRot());
        entity.setXRot(pitch);
    }

    private float smoothAngle(float from, float to, float maxStep) {
        float d = ((to - from + 540.0f) % 360.0f) - 180.0f;
        return from + Math.max(-maxStep, Math.min(maxStep, d));
    }

    private boolean handlePreAttack(Minecraft client) {
        if (rose == null || client.hitResult == null || client.hitResult.getType() != net.minecraft.world.phys.HitResult.Type.ENTITY) return false;
        if (!(client.hitResult instanceof net.minecraft.world.phys.EntityHitResult hit) || hit.getEntity() != rose) return false;
        roseAngryTicks = 20 * 8;
        exploreEnabled = true;
        followEnabled = false;
        task = "none";
        taskInfo = "marah karena dipukul";
        rose.swing(InteractionHand.MAIN_HAND);
        say(client, "Hei! Aku sengaja dipukul? 😤 Aku pergi dulu. Jangan panggil aku selama beberapa detik.");
        return true;
    }

    private void runAngryRetreat(Minecraft client) {
        if (rose == null || client.player == null) return;
        Player p = client.player;
        Vec3 away = rose.position().subtract(p.position());
        Vec3 horizontal = new Vec3(away.x, 0, away.z);
        if (horizontal.lengthSqr() < 0.01) horizontal = new Vec3(1, 0, 0);
        horizontal = horizontal.normalize();
        Vec3 target = rose.position().add(horizontal.scale(8.0));
        groundedNavigate(client, target, 0.13);
        smoothLookAt(rose, target.add(0, 1.2, 0), 20.0f);
    }

    private void runExploration(Minecraft client) {
        if (rose == null || client.player == null || exploreCooldown > 0) return;
        if (exploreTarget == null || rose.distanceToSqr(exploreTarget) < 4.0 || rose.distanceTo(client.player) > 24.0) {
            double angle = RANDOM.nextDouble() * Math.PI * 2.0;
            double radius = 7.0 + RANDOM.nextDouble() * 10.0;
            exploreTarget = new Vec3(client.player.getX() + Math.cos(angle) * radius, client.player.getY(), client.player.getZ() + Math.sin(angle) * radius);
        }
        exploreCooldown = 2;
        groundedNavigate(client, exploreTarget, 0.095);
        if (rose.distanceToSqr(exploreTarget) < 4.0) {
            rose.swing(InteractionHand.MAIN_HAND);
        }
    }

    private void handleSocialIntent(Minecraft client, String text) {
        if (!client.hasSingleplayerServer() || rose == null || roseAngryTicks > 0) return;
        String l = normalize(text);
        if (containsAny(l, "ajak aku", "ayo pergi", "ayo jalan", "mau jalan", "temani aku jalan")) {
            followEnabled = true;
            exploreEnabled = false;
            task = "none";
            if (invitationCooldown == 0) {
                invitationCooldown = 80;
                say(client, "Ayo! Aku ikut kamu. Kamu yang tentukan tujuan, aku akan menjaga jarak dan menyusul kalau tertinggal.");
            }
            return;
        }
        if (containsAny(l, "kamu malu", "rose malu", "jangan malu", "malu dong")) {
            shyGestureTicks = 50;
            if (rose != null) {
                smoothLookAt(rose, client.player.position().add(0, 1.2, 0), 360.0f);
                rose.swing(InteractionHand.MAIN_HAND);
            }
            say(client, "Hehe... aku agak malu. 😳 Tapi tenang, aku tetap teman perjalananmu.");
        }
    }

    private void handleTaskIntent(Minecraft client, String text) {
        String l = normalize(text);
        if (!client.hasSingleplayerServer()) return;
        if (containsAny(l, "jangan ikut", "berhenti ikut", "stop follow", "berhenti mengikuti")) {
            followEnabled = false; task = "none"; exploreEnabled = false; return;
        }
        if (containsAny(l, "ikut aku", "ikuti aku", "ikuti saya", "follow aku", "follow saya", "temani aku")) {
            followEnabled = true; task = "none"; exploreEnabled = false; return;
        }
        if (containsAny(l, "nebang pohon", "tebang pohon", "cari kayu", "ambil kayu", "chop tree")) {
            task = "chop"; taskInfo = "mencari kayu yang bisa dijangkau"; taskCooldown = 0; return;
        }
        if (containsAny(l, "kumpulkan barang", "ambil barang", "ambil item", "cari item", "kumpulin")) {
            task = "gather"; taskInfo = "mencari item drop terdekat"; taskCooldown = 0; return;
        }
        if (containsAny(l, "masukkan ke chest", "taruh di chest", "simpan ke chest", "deposit ke chest")) {
            task = "deposit"; taskInfo = "mencari chest terdekat"; taskCooldown = 0; return;
        }
        if (containsAny(l, "eksplor", "jelajah", "explore", "jalan-jalan")) {
            exploreEnabled = true; followEnabled = false; task = "none"; taskInfo = "mengeksplorasi area sekitar"; exploreTarget = null; exploreCooldown = 0; return;
        }
        if (containsAny(l, "berhenti eksplor", "stop eksplor", "jangan eksplor", "stop jelajah")) {
            exploreEnabled = false; task = "none"; taskInfo = ""; return;
        }
        if (containsAny(l, "berhenti tugas", "stop tugas", "batalkan tugas", "cancel task", "stop")) {
            task = "none"; taskInfo = ""; exploreEnabled = false; return;
        }
        if (containsAny(l, "buat rumah", "bangun rumah", "build house", "buat struktur", "bangun struktur")) {
            task = "plan"; taskInfo = "rencana rumah"; taskCooldown = 0; return;
        }
    }

    private void runTask(Minecraft client) {
        if (task.equals("none") || taskCooldown > 0 || client.player == null || client.level == null) return;
        taskCooldown = 40;
        switch (task) {
            case "chop" -> doChop(client);
            case "gather" -> doGather(client);
            case "deposit" -> doDeposit(client);
            case "plan" -> { task = "none"; say(client, housePlan(client, 7)); }
            default -> task = "none";
        }
    }

    private void doChop(Minecraft client) {
        Player p = client.player;
        BlockPos base = p.blockPosition();
        BlockPos target = null;
        double best = Double.MAX_VALUE;
        for (int x = -5; x <= 5; x++) for (int y = -3; y <= 5; y++) for (int z = -5; z <= 5; z++) {
            BlockPos pos = base.offset(x, y, z);
            String id = client.level.getBlockState(pos).getBlock().getName().getString().toLowerCase(Locale.ROOT);
            if ((id.contains("log") || id.contains("wood") || id.contains("stem")) && p.distanceToSqr(pos.getX()+0.5, pos.getY()+0.5, pos.getZ()+0.5) < best) {
                best = p.distanceToSqr(pos.getX()+0.5, pos.getY()+0.5, pos.getZ()+0.5);
                target = pos;
            }
        }
        if (target == null) {
            task = "none";
            say(client, "Aku tidak menemukan batang kayu yang bisa kujangkau. Dekatkan aku/dirimu ke pohon dulu.");
            return;
        }
        if (client.gameMode != null && client.gameMode.destroyBlock(target)) {
            taskInfo = "menebang " + target.getX() + "," + target.getY() + "," + target.getZ();
        } else {
            task = "none";
            say(client, "Aku menemukan kayu di " + target.getX() + "," + target.getY() + "," + target.getZ() + ", tetapi interaksi normal Minecraft tidak mengizinkanku memecahnya dari jarak itu.");
        }
    }

    private void doGather(Minecraft client) {
        Player p = client.player;
        ItemEntity nearest = null;
        double best = 32 * 32;
        for (Entity e : client.level.entitiesForRendering()) {
            if (e instanceof ItemEntity item && item.isAlive()) {
                double d = item.distanceToSqr(p);
                if (d < best) { best = d; nearest = item; }
            }
        }
        if (nearest == null) {
            task = "none";
            say(client, "Tidak ada item drop dalam radius 32 blok.");
            return;
        }
        String name = nearest.getItem().getHoverName().getString();
        double dx = nearest.getX() - p.getX();
        double dz = nearest.getZ() - p.getZ();
        say(client, "Item terdekat: " + name + " x" + nearest.getItem().getCount() + ". Arah " + directionFromVector(dx, dz) + ", sekitar " + Math.round(Math.sqrt(best)) + " blok. Mendekatlah dan item akan masuk ke inventory secara normal.");
        task = "none";
    }

    private void doDeposit(Minecraft client) {
        // Opening and rearranging a chest is intentionally not faked. We locate the nearest
        // chest and tell the player exactly where it is; the next version can automate the
        // normal container clicks once a chest is opened.
        BlockPos p = client.player.blockPosition();
        BlockPos nearest = findBlock(client, p, 12, "chest");
        if (nearest == null) { task = "none"; say(client, "Aku tidak menemukan chest dalam radius 12 blok."); return; }
        task = "none";
        say(client, "Chest terdekat ada di " + nearest.getX() + ", " + nearest.getY() + ", " + nearest.getZ() + ". Aku tidak akan memalsukan klik inventory; buka chest itu dan aku bisa membantumu menentukan item yang perlu disimpan.");
    }

    private BlockPos findBlock(Minecraft client, BlockPos center, int radius, String name) {
        BlockPos best = null; double dist = Double.MAX_VALUE;
        for (int x=-radius;x<=radius;x++) for(int y=-radius;y<=radius;y++) for(int z=-radius;z<=radius;z++) {
            BlockPos pos=center.offset(x,y,z);
            String n=client.level.getBlockState(pos).getBlock().getName().getString().toLowerCase(Locale.ROOT);
            if(n.contains(name) && center.distSqr(pos)<dist){dist=center.distSqr(pos);best=pos;}
        }
        return best;
    }

    private String answer(Minecraft client, String text) {
        String l = normalize(text);
        if (containsAny(l, "siapa kamu", "kamu siapa", "apa kamu"))
            return "Aku Rose, companion AI untuk Minecraft. Kepribadianku ramah, tenang, sedikit cerewet kalau perlu, dan fokus membantu. Di singleplayer aku bisa hadir sebagai avatar Alex dan mengikuti kamu; di multiplayer aku hanya menjadi assistant chat.";
        if (containsAny(l, "ikuti aku", "ikut aku", "temani aku", "follow aku"))
            return client.hasSingleplayerServer() ? "Siap. Aku akan tetap dekat denganmu." : "Di multiplayer aku tetap chat-only, jadi aku tidak akan menggerakkan avatar atau mengubah dunia server.";
        if (containsAny(l, "siapa di sekitar", "player sekitar", "pemain sekitar", "player dekat", "pemain dekat", "arah player", "arah pemain")) return nearbyPlayersReply(client);
        if (containsAny(l, "struktur", "rumah", "bangunan", "build", "bangunkan")) return housePlan(client, 7);
        if (containsAny(l, "tugas", "task", "sedang apa", "lagi ngapain")) return "Tugas Rose: " + task + (taskInfo.isBlank() ? "" : " — " + taskInfo) + ". Follow=" + (followEnabled ? "aktif" : "mati") + ".";
        if (containsAny(l, "hp rose", "darah rose", "survival rose", "keadaan rose")) return String.format(Locale.ROOT, "State Rose: HP %.1f/20, hunger %d/20, respawn=%s.", roseHealth, roseHunger, roseRespawnTicks > 0 ? "sedang" : "siap");
        if (containsAny(l, "koordinat", "coordinate", "coords", "posisi", "xyz", "x y z")) return coordinatesReply(client);
        if (containsAny(l, "armor", "armour", "baju besi", "zirah", "equipment")) return armorReply(client);
        if (containsAny(l, "inventory", "inventori", "barangku", "isi tas")) return inventoryReply(client);
        if (containsAny(l, "hp", "health", "darah", "nyawa")) return healthReply(client);
        if (containsAny(l, "lapar", "hunger", "makan", "kenyang")) return hungerReply(client);
        if (containsAny(l, "xp", "experience", "levelku", "level aku")) return xpReply(client);
        if (containsAny(l, "efek", "effect", "buff", "debuff")) return effectsReply(client);
        if (containsAny(l, "arah", "menghadap mana", "hadap mana", "facing")) return facingReply(client);
        if (containsAny(l, "siang atau malam", "sekarang malam", "sekarang siang", "jam berapa", "waktu sekarang")) return worldTimeReply(client);
        if (containsAny(l, "cuaca", "hujan", "petir")) return weatherReply(client);
        if (containsAny(l, "biome", "biom")) return biomeReply(client);
        if (containsAny(l, "dimensi", "dimension", "nether", "end")) return dimensionReply(client);
        if (containsAny(l, "lihat apa", "yang aku lihat", "blok apa", "target")) return lookingAtReply(client);
        if (containsAny(l, "mob sekitar", "ada mob", "entity sekitar", "entitas sekitar")) return nearbyReply(client);
        if (containsAny(l, "aman", "bahaya", "situasi")) return safetyReply(client);
        if (containsAny(l, "fps", "lag", "lemot", "performa", "ram", "render distance")) return performanceReply(client);
        if (containsAny(l, "perasaanku", "perasaan aku", "mood aku", "aku merasa")) return moodReply();
        if (!"netral".equals(mood)) return moodAwareReply();
        if (containsAny(l, "halo", "hai", "hi", "hey")) return "Hai. Aku di sini. Mau ngobrol, cek keadaanmu, mencari resource, atau merencanakan bangunan?";
        if (containsAny(l, "terima kasih", "makasih", "thanks")) return "Sama-sama. Aku senang membantu.";
        return "Aku memahami pertanyaanmu sebagai: '" + shorten(text, 100) + "'. Aku bisa membaca state Minecraft dan menjalankan beberapa tugas singleplayer. Kalau ingin aksi, bilang misalnya: 'ikuti aku', 'tebang pohon', 'kumpulkan barang', 'taruh di chest', atau 'buat rencana rumah'.";
    }

    private String nearbyPlayersReply(Minecraft client) {
        List<String> out = new ArrayList<>();
        for (Player p : client.level.players()) {
            if (p == client.player || p == rose) continue;
            double dx=p.getX()-client.player.getX(), dz=p.getZ()-client.player.getZ();
            out.add(p.getGameProfile().name()+" — "+Math.round(Math.sqrt(dx*dx+dz*dz))+" blok, arah "+directionFromVector(dx,dz)+" (X "+Math.round(p.getX())+", Y "+Math.round(p.getY())+", Z "+Math.round(p.getZ())+")");
        }
        return out.isEmpty()?"Tidak ada pemain lain yang terlihat saat ini.":"Pemain yang terlihat: "+String.join("; ",out)+".";
    }

    private String directionFromVector(double dx,double dz){
        double angle=Math.toDegrees(Math.atan2(-dx,dz));
        if(angle<0)angle+=360;
        String[] dirs={"selatan","barat daya","barat","barat laut","utara","timur laut","timur","tenggara"};
        return dirs[(int)Math.round(angle/45.0)%8];
    }

    private String coordinatesReply(Minecraft client){Player p=client.player;return String.format(Locale.ROOT,"Koordinatmu: X %.1f, Y %.1f, Z %.1f (blok %d, %d, %d).",p.getX(),p.getY(),p.getZ(),p.blockPosition().getX(),p.blockPosition().getY(),p.blockPosition().getZ());}
    private String armorReply(Minecraft c){Player p=c.player;return "Armor: kepala="+itemLong(p.getItemBySlot(EquipmentSlot.HEAD))+", dada="+itemLong(p.getItemBySlot(EquipmentSlot.CHEST))+", kaki="+itemLong(p.getItemBySlot(EquipmentSlot.LEGS))+", sepatu="+itemLong(p.getItemBySlot(EquipmentSlot.FEET))+".";}
    private String inventoryReply(Minecraft c){Player p=c.player;List<String> a=new ArrayList<>();for(int i=0;i<p.getInventory().getContainerSize();i++){ItemStack s=p.getInventory().getItem(i);if(!s.isEmpty())a.add(itemLong(s));}if(a.isEmpty())return"Inventory kosong.";return"Inventory terisi "+a.size()+" slot: "+String.join(", ",a.subList(0,Math.min(16,a.size())))+(a.size()>16?" ...":"")+".";}
    private String healthReply(Minecraft c){Player p=c.player;return String.format(Locale.ROOT,"HP %.1f/%.1f, armor %.1f, absorption %.1f.",p.getHealth(),p.getMaxHealth(),p.getArmorValue(),p.getAbsorptionAmount());}
    private String hungerReply(Minecraft c){var f=c.player.getFoodData();return"Hunger "+f.getFoodLevel()+"/20, saturation "+String.format(Locale.ROOT,"%.1f",f.getSaturationLevel())+".";}
    private String xpReply(Minecraft c){Player p=c.player;return String.format(Locale.ROOT,"Level XP %d, progress %.1f%%, total %d.",p.experienceLevel,p.experienceProgress*100,p.totalExperience);}
    private String effectsReply(Minecraft c){List<String>a=new ArrayList<>();for(var e:c.player.getActiveEffects())a.add(e.getEffect().value().getDisplayName().getString()+" x"+(e.getAmplifier()+1)+" ("+Math.max(0,e.getDuration()/20)+"s)");return a.isEmpty()?"Tidak ada effect aktif.":"Effect aktif: "+String.join(", ",a)+".";}
    private String facingReply(Minecraft c){return"Kamu menghadap "+c.player.getDirection().getName()+" (yaw "+String.format(Locale.ROOT,"%.1f",c.player.getYRot())+"°).";}
    private String worldTimeReply(Minecraft c){long t=Math.floorMod(c.level.getOverworldClockTime(),24000L);int h=(int)(((t/1000L)+6)%24),m=(int)((t%1000L)*60/1000L);String label=h>=5&&h<11?"pagi":h>=11&&h<15?"siang":h>=15&&h<18?"sore":"malam";return String.format(Locale.ROOT,"Jam dunia Minecraft %02d:%02d (%s).",h,m,label);}
    private String weatherReply(Minecraft c){return c.level.isThundering()?"Badai petir.":c.level.isRaining()?"Hujan.":"Cerah.";}
    private String biomeReply(Minecraft c){return"Biome: "+c.level.getBiome(c.player.blockPosition()).getRegisteredName()+".";}
    private String dimensionReply(Minecraft c){return"Dimension: "+c.level.dimension().identifier()+".";}
    private String lookingAtReply(Minecraft c){if(c.hitResult==null)return"Tidak ada target.";return"Target yang kamu lihat: "+c.hitResult.getType()+".";}
    private String nearbyReply(Minecraft c){int n=0;double d0=999;String name="tidak ada";for(Entity e:c.level.entitiesForRendering()){if(e==c.player||e==rose)continue;double d=e.distanceTo(c.player);if(d<=32){n++;if(d<d0){d0=d;name=e.getName().getString();}}}return n==0?"Tidak ada entity lain dalam 32 blok.":"Ada "+n+" entity dalam 32 blok. Terdekat: "+name+" sekitar "+Math.round(d0)+" blok.";}
    private String safetyReply(Minecraft c){if(c.player.getHealth()<=6)return"HP-mu rendah. Prioritas: cari tempat aman dan pulihkan HP.";if(c.player.getFoodData().getFoodLevel()<=6)return"Kamu lapar. Cari makanan.";return"Dari state dasar yang kulihat, tidak ada bahaya besar yang terdeteksi.";}
    private String performanceReply(Minecraft c){return"FPS "+c.getFps()+", RAM "+((Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory())/1048576)+" MB, render distance "+c.options.getEffectiveRenderDistance()+" chunk.";}
    private String housePlan(Minecraft c,int size){int x=c.player.blockPosition().getX(),y=c.player.blockPosition().getY(),z=c.player.blockPosition().getZ();return"Rencana rumah "+size+"x"+size+": fondasi di sekitar X="+x+", Y="+y+", Z="+z+"; dinding tinggi 4 blok; pintu 1 di sisi depan; jendela di dua sisi; atap bertingkat; interior: chest, crafting table, furnace, bed. Aku bisa memakai rencana ini sebagai target build singleplayer, tetapi aku tidak akan menempatkan blok secara diam-diam tanpa resource dan interaksi yang valid.";}
    private String contextualMessage(Minecraft c){if(c.player.getHealth()<=6)return"HP-mu rendah. Kita cari tempat aman dulu?";if(c.player.getFoodData().getFoodLevel()<=6)return"Kamu mulai lapar. Mau cari makanan?";if(c.hasSingleplayerServer()&&followEnabled)return"Aku masih di dekatmu. Kalau kamu mau jalan-jalan, bilang saja 'ajak aku jalan' dan aku akan ikut.";return"Aku masih mengamati dunia. Kalau butuh aku, panggil 'Rose'.";}
    private String moodAwareReply(){return switch(mood){case"sedih"->"Aku menangkap kamu mungkin sedang sedih dari tulisanmu. Aku bisa mendengarkan kalau kamu mau cerita.";case"marah"->"Kedengarannya kamu sedang kesal. Kita bisa membahasnya pelan-pelan.";case"cemas"->"Aku menangkap ada kekhawatiran. Kita bisa pecah masalahnya satu per satu.";case"lelah"->"Kedengarannya kamu lelah. Kita bisa santai dulu.";case"bingung"->"Kalau kamu bingung, kita pecah pertanyaannya menjadi langkah kecil.";case"senang"->"Kedengarannya kamu sedang senang. Ceritakan apa yang terjadi.";default->"Aku mendengarkan.";};}
    private String moodReply(){return"Mood yang kutangkap dari bahasa terakhirmu: "+mood+". Ini hanya perkiraan dari kata-kata, bukan pembacaan pikiran.";}
    private String detectMood(String t){String l=normalize(t);if(containsAny(l,"sedih","nangis","kecewa","hancur"))return"sedih";if(containsAny(l,"marah","kesal","kesel","jengkel"))return"marah";if(containsAny(l,"cemas","khawatir","takut","panik"))return"cemas";if(containsAny(l,"capek","lelah","letih","ngantuk"))return"lelah";if(containsAny(l,"bingung","gak ngerti","tidak ngerti","susah"))return"bingung";if(containsAny(l,"senang","bahagia","gembira","seru","keren","mantap"))return"senang";return"netral";}
    private void remember(String m){lastPlayerMessage=m;conversation.addLast(m);while(conversation.size()>16)conversation.removeFirst();}
    private String itemLong(ItemStack s){if(s.isEmpty())return"kosong";String n=s.getHoverName().getString()+" x"+s.getCount();if(s.isDamageableItem())n+=" (durability "+(s.getMaxDamage()-s.getDamageValue())+"/"+s.getMaxDamage()+")";return n;}
    private String normalize(String s){return s.toLowerCase(Locale.ROOT).replaceAll("\\s+"," ").trim();}
    private boolean containsAny(String t,String...w){for(String s:w)if(t.contains(s))return true;return false;}
    private String shorten(String s,int n){return s==null?"":s.length()<=n?s:s.substring(0,n-3)+"...";}

    public static void chat(Minecraft client,String message){if(INSTANCE==null||client.player==null||message==null||message.isBlank())return;INSTANCE.remember(message.trim());INSTANCE.mood=INSTANCE.detectMood(message);INSTANCE.handleTaskIntent(client,message);INSTANCE.pendingReply=INSTANCE.answer(client,message.trim());INSTANCE.replyDelay=2;}
    public static void say(Minecraft client,String message){if(client.player!=null)client.player.sendSystemMessage(Component.literal(TAG+message));}
    public static void mood(Minecraft client){if(INSTANCE!=null)say(client,INSTANCE.moodReply());}
    public static void performance(Minecraft client){if(INSTANCE!=null)say(client,INSTANCE.performanceReply(client));}
    public static void companion(Minecraft client){if(INSTANCE==null||client.player==null)return;if(!client.hasSingleplayerServer()){say(client,"Companion avatar hanya aktif di singleplayer. Di multiplayer aku chat-only.");return;}INSTANCE.followEnabled=true;INSTANCE.ensureRose(client);say(client,"Aku sudah muncul sebagai Rose dan akan mengikutimu.");}
    public static void follow(Minecraft client){if(INSTANCE==null)return;INSTANCE.followEnabled=true;say(client,"Mode mengikuti aktif.");}
    public static void stop(Minecraft client){if(INSTANCE==null)return;INSTANCE.followEnabled=false;INSTANCE.exploreEnabled=false;INSTANCE.task="none";INSTANCE.taskInfo="";say(client,"Aku berhenti mengikuti, eksplorasi, dan menghentikan tugas aktif.");}
    public static void explore(Minecraft client){if(INSTANCE==null)return;if(!client.hasSingleplayerServer()){say(client,"Eksplorasi avatar hanya aktif di singleplayer.");return;}INSTANCE.exploreEnabled=true;INSTANCE.followEnabled=false;INSTANCE.task="none";INSTANCE.exploreTarget=null;INSTANCE.say(client,"Baik. Aku boleh mengeksplorasi area sekitar, tapi tetap menjaga jarak agar tidak terlalu jauh darimu.");}
    public static void invite(Minecraft client){
        if(INSTANCE==null)return;
        if(!client.hasSingleplayerServer()){say(client,"Mode menemani avatar hanya aktif di singleplayer.");return;}
        INSTANCE.followEnabled=true; INSTANCE.exploreEnabled=false; INSTANCE.task="none";
        say(client,"Ayo jalan. Aku akan ikut ke mana pun kamu pergi dan menyusul kalau tertinggal.");
    }
    public static void task(Minecraft client,String t){if(INSTANCE==null)return;INSTANCE.handleTaskIntent(client,t);say(client,"Tugas diterima: "+INSTANCE.task+" — "+(INSTANCE.taskInfo.isBlank()?"siap":INSTANCE.taskInfo)+".");}
}
