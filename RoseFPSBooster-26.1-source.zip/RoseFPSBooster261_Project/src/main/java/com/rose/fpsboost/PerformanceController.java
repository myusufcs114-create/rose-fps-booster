package com.rose.fpsboost;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class PerformanceController {
    private static final int TARGET_FPS = 200;
    private static final int START_RENDER_DISTANCE = 20;
    private static final int MIN_RENDER_DISTANCE = 16;
    private static final int MAX_RENDER_DISTANCE = 24;
    private static final int SIMULATION_DISTANCE = 8;

    private Object minecraft;
    private int ticks;
    private int lastRenderDistance = -1;
    private int lowFpsSamples;
    private int highFpsSamples;
    private boolean initialized;

    public void onClientInit() {
        initialized = false;
    }

    public void tick(Object client) {
        if (!initialized) {
            minecraft = client;
            applyBaseline();
            initialized = true;
            return;
        }

        // Check every ~2 seconds instead of constantly rebuilding chunks.
        if (++ticks < 40) return;
        ticks = 0;

        int fps = readFps();
        if (fps <= 0) return;

        if (fps < 155) {
            lowFpsSamples++;
            highFpsSamples = 0;
        } else if (fps >= 185) {
            highFpsSamples++;
            lowFpsSamples = 0;
        } else {
            lowFpsSamples = 0;
            highFpsSamples = 0;
        }

        // Reduce only after sustained load.
        if (lowFpsSamples >= 2) {
            changeRenderDistance(-2);
            lowFpsSamples = 0;
        }

        // Restore only after sustained headroom.
        if (highFpsSamples >= 4) {
            changeRenderDistance(+2);
            highFpsSamples = 0;
        }
    }

    private void applyBaseline() {
        try {
            Object options = getOptions();
            setOption(options, "renderDistance", START_RENDER_DISTANCE);
            setOption(options, "simulationDistance", SIMULATION_DISTANCE);
            setOption(options, "maxFps", TARGET_FPS);
            setOption(options, "enableVsync", false);
            lastRenderDistance = START_RENDER_DISTANCE;
        } catch (Throwable ignored) {
            // Never crash Minecraft if a patch changes an Options member.
        }
    }

    private void changeRenderDistance(int delta) {
        int current = lastRenderDistance > 0 ? lastRenderDistance : START_RENDER_DISTANCE;
        int next = Math.max(MIN_RENDER_DISTANCE,
                Math.min(MAX_RENDER_DISTANCE, current + delta));

        if (next == current) return;

        try {
            setOption(getOptions(), "renderDistance", next);
            lastRenderDistance = next;
        } catch (Throwable ignored) {
        }
    }

    private int readFps() {
        try {
            Method m = minecraft.getClass().getMethod("getFps");
            Object value = m.invoke(minecraft);
            if (value instanceof Number n) return n.intValue();
        } catch (Throwable ignored) {
        }
        return 0;
    }

    private Object getOptions() throws Exception {
        Field f = findField(minecraft.getClass(), "options");
        if (f == null) throw new NoSuchFieldException("options");
        f.setAccessible(true);
        return f.get(minecraft);
    }

    private static void setOption(Object options, String methodName, Object value)
            throws Exception {
        Method getter = options.getClass().getMethod(methodName);
        Object option = getter.invoke(options);

        for (Method m : option.getClass().getMethods()) {
            if (m.getName().equals("set") && m.getParameterCount() == 1) {
                m.invoke(option, value);
                return;
            }
        }

        throw new NoSuchMethodException("Option.set");
    }

    private static Field findField(Class<?> type, String name) {
        Class<?> c = type;
        while (c != null) {
            try {
                return c.getDeclaredField(name);
            } catch (NoSuchFieldException ignored) {
                c = c.getSuperclass();
            }
        }
        return null;
    }
}
