package com.rose.fpsboost;

import net.fabricmc.api.ClientModInitializer;

public final class RoseFpsBooster implements ClientModInitializer {
    public static final PerformanceController CONTROLLER = new PerformanceController();

    @Override
    public void onInitializeClient() {
        CONTROLLER.onClientInit();
    }
}
