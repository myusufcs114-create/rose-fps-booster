# Rose FPS Booster — Minecraft 26.1

Target: Minecraft 26.1 + Fabric Loader 0.19.1.

Profile:
- FPS target/cap: 200
- VSync: OFF
- Starting render distance: 20 chunks
- Simulation distance: 8 chunks
- Adaptive render distance: 16–24 chunks
- Chunk-distance changes are deliberately infrequent to reduce stutter.

This does not guarantee 200 FPS. It targets 200 FPS while trying to preserve a wide view distance. Actual FPS is limited by the phone, GPU driver, MobileGlues backend, shaders, world complexity, and other mods.

Fabric's 26.1 documentation says JDK 25 is required for development. Build with JDK 25:

    ./gradlew build

Then place:
    build/libs/rose-fps-booster-1.0.0.jar

in the Minecraft 26.1 mods folder.
