# Minecraft AI Assistant — Minecraft 26.1

Client-side Fabric companion for Minecraft 26.1.

## What changed in v1.1.0

- Replies to the player's chat in singleplayer.
- On multiplayer, only responds when addressed with `AI`, `@AI`, `AI:` or `AI,`.
- Detects a likely mood from the words used in the current conversation (for example: happy, sad, angry, anxious, tired, confused). This is a text-based estimate, not mind-reading.
- Keeps the latest message and mood in memory for the current game session.
- Uses the actual Minecraft Overworld clock, including the 06:00 offset, so day/night messages are no longer shifted.
- Performance chatter is less intrusive and only warns when FPS is actually low.
- `/ai chat <message>` lets you explicitly talk to the assistant.
- `/ai mood` reports the current text-based mood estimate.
- `/ai performance` reports FPS/RAM/render distance/entity count.

The conversation engine is offline and rule-based in this version; no chat text is sent to an external AI service.

## Commands

- `/ai status`
- `/ai chat <message>`
- `/ai mood`
- `/ai performance`
- `/ai quiet`

## Build

Requires Java 25 and Gradle 9.4.0. Minecraft 26.1 uses the non-remapping Fabric Loom setup and official Mojang names.
