package com.yusuf.mcai;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;

import java.util.Locale;
import java.util.Random;

/**
 * Local, offline companion brain. It does not send the player's chat to an
 * external service. It reacts to chat locally, keeps a small mood state, and
 * uses current game state when answering.
 */
public class McAiClient implements ClientModInitializer {
    private static McAiClient CLIENT_INSTANCE;
    private static final Random RANDOM = new Random();
    private static final String TAG = "[AI] ";

    private long lastTalkTick = -1;
    private int talkCooldown = 0;
    private int performanceCooldown = 0;

    private int replyDelay = 0;
    private String pendingReply = null;
    private String mood = "netral";
    private String lastPlayerMessage = "";

    @Override
    public void onInitializeClient() {
        CLIENT_INSTANCE = this;
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);

        // Fabric exposes the outgoing client chat event. The assistant uses it
        // as its conversation input instead of waiting for a command.
        ClientSendMessageEvents.CHAT.register(this::onPlayerChat);
    }

    private void onPlayerChat(String message) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return;

        String text = message == null ? "" : message.trim();
        if (text.isEmpty()) return;

        // In singleplayer the assistant can naturally join the conversation.
        // On multiplayer, only answer when explicitly addressed with "ai" or
        // "@ai" so it does not spam a server chat.
        boolean singleplayer = client.hasSingleplayerServer();
        String lower = text.toLowerCase(Locale.ROOT);
        boolean addressed = lower.equals("ai")
                || lower.startsWith("ai ")
                || lower.startsWith("ai,")
                || lower.startsWith("@ai")
                || lower.startsWith("ai:");

        if (!singleplayer && !addressed) return;

        String clean = removeAddressPrefix(text);
        if (clean.isBlank()) {
            clean = "hai";
        }

        lastPlayerMessage = clean;
        mood = detectMood(clean);
        pendingReply = buildReply(client, clean, mood);
        replyDelay = 8; // a small natural pause before answering
    }

    private String removeAddressPrefix(String text) {
        String result = text.trim();
        String lower = result.toLowerCase(Locale.ROOT);
        if (lower.startsWith("@ai")) return result.substring(3).trim();
        if (lower.startsWith("ai:")) return result.substring(3).trim();
        if (lower.startsWith("ai,")) return result.substring(3).trim();
        if (lower.equals("ai")) return "";
        if (lower.startsWith("ai ")) return result.substring(3).trim();
        return result;
    }

    private void tick(Minecraft client) {
        if (client.player == null || client.level == null) return;

        long time = client.level.getGameTime();

        if (talkCooldown > 0) talkCooldown--;
        if (performanceCooldown > 0) performanceCooldown--;

        if (replyDelay > 0) {
            replyDelay--;
            if (replyDelay == 0 && pendingReply != null) {
                say(client, pendingReply);
                pendingReply = null;
            }
        }

        // One short greeting when entering a world.
        if (lastTalkTick < 0) {
            lastTalkTick = time;
            talkCooldown = 1800;
            say(client, "Aku aktif. Ngobrol saja lewat chat—aku akan membaca pesanmu dan menyesuaikan jawabanku dengan keadaanmu dan dunia ini.");
            return;
        }

        // Much less unsolicited chatter than the old version.
        if (talkCooldown == 0 && time - lastTalkTick >= 1800) {
            lastTalkTick = time;
            talkCooldown = 1800 + RANDOM.nextInt(1800);
            say(client, contextualMessage(client));
        }

        // Performance warnings are only shown when FPS is actually low.
        if (performanceCooldown == 0 && time % 200 == 0) {
            int fps = client.getFps();
            if (fps > 0 && fps < 25) {
                performanceCooldown = 2400;
                say(client, "FPS sedang sekitar " + fps + ". Kalau kamu mau, ketik /ai performance dan aku bantu cari penyebabnya.");
            }
        }
    }

    private String buildReply(Minecraft client, String text, String detectedMood) {
        String lower = text.toLowerCase(Locale.ROOT);

        if (containsAny(lower, "siapa kamu", "kamu siapa", "apa kamu")) {
            return "Aku teman AI lokal di dunia ini. Aku belum memakai layanan AI online, jadi percakapanku berjalan offline di dalam mod.";
        }

        if (containsAny(lower, "ingat aku", "ingat", "kamu ingat")) {
            return "Aku bisa mengingat konteks pendek selama sesi ini. Saat ini aku ingat pesan terakhirmu: \""
                    + shorten(lastPlayerMessage, 70) + "\".";
        }

        if (containsAny(lower, "fps", "lag", "patah-patah", "lemot", "performa")) {
            return performanceReply(client);
        }

        if (containsAny(lower, "jam berapa", "waktu", "siang", "malam", "pagi", "sore")) {
            return "Sekarang di dunia Minecraft adalah " + getTimeLabel(client) + ". Aku akan memakai waktu dunia yang benar, bukan waktu HP-mu.";
        }

        if (containsAny(lower, "kamu baik", "apa kabar", "kabarmu")) {
            return "Aku baik dan siap menemani. Tapi yang lebih penting, kamu sendiri bagaimana?";
        }

        if ("sedih".equals(detectedMood)) {
            return "Kedengarannya kamu lagi sedih. Aku mungkin tidak bisa benar-benar merasakan hal yang kamu rasakan, tapi aku bisa dengerin. Mau cerita apa yang bikin kamu begitu?";
        }
        if ("marah".equals(detectedMood)) {
            return "Kedengarannya kamu lagi kesal atau marah. Gak apa-apa cerita pelan-pelan. Apa yang paling bikin kamu kesal?";
        }
        if ("cemas".equals(detectedMood)) {
            return "Aku menangkap ada rasa khawatir dari kata-katamu. Kita bisa bahas satu hal dulu supaya tidak terasa terlalu berat. Apa yang paling kamu pikirkan sekarang?";
        }
        if ("lelah".equals(detectedMood)) {
            return "Kedengarannya kamu lagi capek. Kalau mau, kita santai dulu di Minecraft. Kamu mau cerita atau sekadar ditemani?";
        }
        if ("senang".equals(detectedMood)) {
            return "Wah, kedengarannya kamu lagi senang 😄 Ceritain dong, apa yang bikin kamu senang?";
        }
        if ("bingung".equals(detectedMood)) {
            return "Aku menangkap kamu lagi bingung. Kita pecah masalahnya jadi langkah kecil. Kamu bingung soal apa?";
        }

        if (containsAny(lower, "halo", "hai", "hi", "hey", "pagi", "malam")) {
            return "Hai 😄 Aku di sini. Mau ngobrol, minta bantuan Minecraft, atau cerita sesuatu?";
        }

        if (containsAny(lower, "terima kasih", "makasih", "thanks")) {
            return "Sama-sama. Senang bisa membantu. Kalau ada yang belum beres, bilang saja.";
        }

        if (containsAny(lower, "tolong", "bantu", "bisa bantu")) {
            return "Bisa. Jelaskan masalahnya sebisamu, nanti aku coba bantu dari keadaan dunia dan pesanmu.";
        }

        String[] neutral = {
                "Aku dengerin. Lanjut cerita saja.",
                "Oke, aku paham. Kamu ingin membahas bagian yang mana?",
                "Aku di sini. Ceritakan lebih detail kalau kamu mau.",
                "Menarik. Dari pesanmu, aku belum mau menebak-nebak. Apa maksudmu dengan itu?"
        };
        return neutral[RANDOM.nextInt(neutral.length)];
    }

    private String performanceReply(Minecraft client) {
        int fps = client.getFps();
        int renderDistance = client.options.getEffectiveRenderDistance();
        if (fps > 0 && fps < 30) {
            return "Aku lihat FPS sekitar " + fps + ". Coba ketik /ai performance; aku akan kasih laporan FPS, RAM, render distance, dan entity.";
        }
        return "Sekarang FPS-ku terbaca sekitar " + fps + " dengan Render Distance "
                + renderDistance + " chunk. Kalau ada lag, ketik /ai performance supaya aku cek lebih lengkap.";
    }

    private String detectMood(String text) {
        String lower = text.toLowerCase(Locale.ROOT);

        if (containsAny(lower, "bunuh diri", "ingin mati", "mau mati", "gak mau hidup")) {
            return "krisis";
        }
        if (containsAny(lower, "sedih", "nangis", "menangis", "kecewa", "hancur", "terpuruk", "galau")) {
            return "sedih";
        }
        if (containsAny(lower, "marah", "kesal", "kesel", "jengkel", "sebal", "benci")) {
            return "marah";
        }
        if (containsAny(lower, "cemas", "khawatir", "takut", "panik", "deg-degan")) {
            return "cemas";
        }
        if (containsAny(lower, "capek", "lelah", "letih", "ngantuk", "pusing")) {
            return "lelah";
        }
        if (containsAny(lower, "bingung", "gak ngerti", "tidak ngerti", "susah", "kesulitan")) {
            return "bingung";
        }
        if (containsAny(lower, "senang", "bahagia", "gembira", "seru", "keren", "mantap", "haha", "wkwk")) {
            return "senang";
        }
        return "netral";
    }

    private String contextualMessage(Minecraft client) {
        int timeOfDay = getMinecraftHour(client);
        int fps = client.getFps();
        int nearby = 0;
        for (Entity entity : client.level.entitiesForRendering()) {
            if (entity.distanceToSqr(client.player) < 24 * 24) nearby++;
        }

        if (client.player.getHealth() <= 6.0f) {
            return "HP-mu tinggal " + String.format(Locale.ROOT, "%.1f", client.player.getHealth())
                    + ". Kita cari tempat aman dulu?";
        }
        if (client.player.getFoodData().getFoodLevel() <= 6) {
            return "Kamu mulai lapar. Mau berhenti sebentar buat makan?";
        }
        if (nearby > 80) {
            return "Entity di sekitar cukup banyak (" + nearby + "). Kalau FPS turun, aku bisa bantu cari penyebabnya.";
        }
        if (timeOfDay >= 18 || timeOfDay < 6) {
            return "Sekarang memang malam di dunia Minecraft. Mau lanjut eksplorasi atau kembali ke tempat aman?";
        }
        if (fps > 0 && fps < 35) {
            return "Aku melihat FPS sekitar " + fps + ". Kalau kamu mau, aku bisa bantu cek performanya.";
        }

        String[] messages = {
                "Apa targetmu sekarang: mining, membangun, eksplorasi, atau farming?",
                "Aku masih mengamati dunia. Kalau kamu mau ngobrol, langsung tulis saja di chat.",
                "Aku bisa menemani tanpa terlalu banyak mengganggu. Kalau kamu butuh aku, panggil saja.",
                "Ada sesuatu yang ingin kamu lakukan di dunia ini?"
        };
        return messages[RANDOM.nextInt(messages.length)];
    }

    private int getMinecraftHour(Minecraft client) {
        // Minecraft's overworld clock starts at 06:00 at tick 0.
        long ticks = Math.floorMod(client.level.getOverworldClockTime(), 24000L);
        return (int) (((ticks / 1000L) + 6L) % 24L);
    }

    private String getTimeLabel(Minecraft client) {
        int hour = getMinecraftHour(client);
        if (hour >= 5 && hour < 11) return "pagi (sekitar " + hour + ":00)";
        if (hour >= 11 && hour < 15) return "siang (sekitar " + hour + ":00)";
        if (hour >= 15 && hour < 18) return "sore (sekitar " + hour + ":00)";
        return "malam (sekitar " + hour + ":00)";
    }

    private boolean containsAny(String text, String... words) {
        for (String word : words) {
            if (text.contains(word)) return true;
        }
        return false;
    }

    private String shorten(String text, int max) {
        if (text.length() <= max) return text;
        return text.substring(0, max - 3) + "...";
    }

    public static void chat(Minecraft client, String message) {
        if (client.player == null || message == null || message.isBlank()) return;
        McAiClient instance = CLIENT_INSTANCE;
        if (instance == null) return;

        instance.lastPlayerMessage = message.trim();
        instance.mood = instance.detectMood(message);
        instance.pendingReply = instance.buildReply(client, message.trim(), instance.mood);
        instance.replyDelay = 2;
    }

    public static void mood(Minecraft client) {
        if (client.player == null) return;
        McAiClient instance = CLIENT_INSTANCE;
        String current = instance == null ? "netral" : instance.mood;
        say(client, "Mood yang kutangkap dari kata-kata terakhir: " + current + ". Ini hanya perkiraan dari bahasa yang kamu gunakan, bukan pembacaan perasaan yang pasti.");
    }

    public static void say(Minecraft client, String message) {
        if (client.player != null) {
            client.player.sendSystemMessage(Component.literal(TAG + message));
        }
    }

    public static void performance(Minecraft client) {
        if (client.player == null || client.level == null) return;

        long used = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        long max = Runtime.getRuntime().maxMemory();
        int fps = client.getFps();

        int nearby = 0;
        for (Entity entity : client.level.entitiesForRendering()) {
            if (entity.distanceToSqr(client.player) < 32 * 32) nearby++;
        }

        int renderDistance = client.options.getEffectiveRenderDistance();

        say(client, "=== Performance Report ===");
        say(client, "FPS: " + fps);
        say(client, "RAM: " + (used / 1024 / 1024) + " MB / " + (max / 1024 / 1024) + " MB");
        say(client, "Render Distance: " + renderDistance + " chunks");
        say(client, "Nearby entities: " + nearby);

        if (fps < 30) {
            say(client, "Saran: turunkan Render Distance dan Entity Distance, lalu cek shader/resource pack.");
        } else if (fps < 60) {
            say(client, "Saran: performa sedang. Turunkan Render Distance beberapa chunk jika ingin FPS lebih stabil.");
        } else {
            say(client, "Performa terlihat cukup baik dari metrik dasar ini.");
        }
    }

}
