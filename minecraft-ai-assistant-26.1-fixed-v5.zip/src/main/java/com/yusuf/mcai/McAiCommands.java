package com.yusuf.mcai;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.client.Minecraft;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.literal;

public class McAiCommands implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(literal("ai")
                    .then(literal("performance").executes(ctx -> {
                        McAiClient.performance(Minecraft.getInstance());
                        return 1;
                    }))
                    .then(literal("status").executes(ctx -> {
                        McAiClient.say(Minecraft.getInstance(),
                                "Aku aktif. Tulis langsung di chat untuk ngobrol denganku. /ai performance untuk laporan performa.");
                        return 1;
                    }))
                    .then(literal("mood").executes(ctx -> {
                        McAiClient.mood(Minecraft.getInstance());
                        return 1;
                    }))
                    .then(literal("chat")
                            .then(argument("message", StringArgumentType.greedyString()).executes(ctx -> {
                                McAiClient.chat(Minecraft.getInstance(), StringArgumentType.getString(ctx, "message"));
                                return 1;
                            })))
                    .then(literal("quiet").executes(ctx -> {
                        McAiClient.say(Minecraft.getInstance(),
                                "Mode quiet belum tersedia pada versi ini.");
                        return 1;
                    })));
        });
    }
}
