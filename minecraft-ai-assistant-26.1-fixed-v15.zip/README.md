# Rose AI Assistant — v1.3.0 / Minecraft 26.1

Rose is a client-side Fabric companion for Minecraft 26.1.

## Personality
Rose uses a friendly, calm, feminine-coded assistant persona inspired by a game-system/JARVIS style companion. This is a game character personality, not a romantic roleplay system.

## Singleplayer
- Spawns a client-side Alex-style player avatar named Rose.
- Follows the player and can be stopped/resumed.
- Reads coordinates, armor, inventory, health, hunger, XP, effects, biome, time, weather, dimension, target, entities and performance.
- Finds nearby dropped items and reports direction/distance.
- Finds nearby chests and reports their location.
- Can perform limited normal block-breaking assistance (for example, chopping a reachable log) using the player's normal interaction manager.
- Can create structure plans such as a 7x7 starter house and explain required layout/resources.
- Has short conversation memory and mood estimation.

## Multiplayer
- The avatar and world-changing task automation are disabled.
- Rose remains a chat-only assistant and only answers when addressed (Rose/AI/@Rose).
- It can list visible players, coordinates and relative directions.
- It never attempts to inject fake world-editing actions into multiplayer servers.

## Commands
- `/ai companion`
- `/ai follow`
- `/ai stop`
- `/ai status`
- `/ai players`
- `/ai task <task>`
- `/ai chat <message>`
- `/ai mood`
- `/ai performance`

Natural language examples:
- `Rose, ikuti aku`
- `Rose, tebang pohon`
- `Rose, kumpulkan barang`
- `Rose, taruh di chest`
- `Rose, buat rumah`
- `Rose, siapa player di sekitar dan arahnya?`

## v11 changes
- Adds a friendly invitation/follow mode: `Rose, ajak aku jalan` or `/ai invite` keeps Rose in follow mode and lets her catch up on foot when she falls behind.
- Keeps the companion with the player across dimension changes by recreating the client-side avatar in the new client level.
- Adds a brief non-romantic shy/bashful social animation when explicitly requested (for example, `Rose, kamu malu`).
- Follow catch-up is faster when Rose is far away, but it still uses movement rather than teleporting.
- `/ai stop` cancels follow, exploration and active tasks.

## v10 changes
- Adds a client-side survival foundation for Rose: independent HP/hunger state, death/respawn loop, and basic hostile-mob avoidance.
- Adds a non-romantic flower gift response: when the player is close and holding a flower, Rose faces them and performs a friendly greeting/wave animation.
- Full server-authoritative NPC survival (real inventory, crafting, mining, block placement, chest transfer, and real mob combat) is not yet implemented; that requires moving the companion to a common/server-side entity architecture.


## v1.4 Rose Skin

Rose now uses a bundled 64x64 Minecraft player skin instead of relying on the default Alex appearance. The skin is red-haired with a red/black/gold 18th-century-inspired outfit and is supplied directly by the `RoseRemotePlayer` client avatar.

The skin is stored at `assets/mc_ai_assistant/textures/entity/rose_skin.png`.


## v13 — Grounded Rose Movement

This version replaces the old follow movement with a client-side grounded controller. Rose uses Minecraft collision checks, gravity, a jump controller, obstacle steering, and a small local A* grid pathfinder because the current avatar is a `RemotePlayer`, not a `MobEntity` that can directly own vanilla `EntityNavigation`. Normal follow movement no longer changes Rose's X/Y/Z directly; it uses `move(MoverType.SELF, ...)`, so terrain collision participates.

Features:
- No normal follow teleport/blink.
- Manual gravity with grounded collision.
- One-block jump handling.
- Steering around trees, walls, and corners.
- Local A* path search around obstacles.
- Rebuilds path when Rose gets stuck.
- Exploration uses the same grounded navigation.
- Angry retreat uses the same navigation.

This is still a client-side companion. It is not yet a server-authoritative survival NPC; that remains a separate architecture step for real inventory, crafting, mining, building, combat, death, and respawn.
