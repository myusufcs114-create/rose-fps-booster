package com.yusuf.mcai;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.core.ClientAsset;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerModelType;
import net.minecraft.world.entity.player.PlayerSkin;

/** Client-side Rose avatar with the bundled red-haired 18th-century-inspired skin. */
public class RoseRemotePlayer extends RemotePlayer {
    private static final Identifier ROSE_SKIN = Identifier.parse("mc_ai_assistant:textures/entity/rose_skin");

    private static final PlayerSkin ROSE_PLAYER_SKIN = PlayerSkin.insecure(
            new ClientAsset.ResourceTexture(ROSE_SKIN),
            null,
            null,
            PlayerModelType.WIDE
    );

    public RoseRemotePlayer(ClientLevel level, GameProfile profile) {
        super(level, profile);
    }

    @Override
    public PlayerSkin getSkin() {
        return ROSE_PLAYER_SKIN;
    }
}
