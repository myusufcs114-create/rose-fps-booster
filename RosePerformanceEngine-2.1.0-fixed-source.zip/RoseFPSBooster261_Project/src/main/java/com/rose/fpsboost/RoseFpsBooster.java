package com.rose.fpsboost;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

/**
 * Rose Performance Engine v2.1.
 *
 * Uses Fabric's client tick event instead of a Mixin for the controller tick,
 * which makes the mod more robust with Minecraft 26.1 launchers.
 */
public final class RoseFpsBooster implements ClientModInitializer {
    public static final PerformanceController CONTROLLER = new PerformanceController();

    @Override
    public void onInitializeClient() {
        CONTROLLER.onClientInit();
        ClientTickEvents.END_CLIENT_TICK.register(CONTROLLER::tick);
    }
}
