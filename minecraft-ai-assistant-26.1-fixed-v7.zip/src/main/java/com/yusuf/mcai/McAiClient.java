package com.yusuf.mcai;

import com.mojang.authlib.GameProfile;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * Rose AI Companion v1.3 / Minecraft 26.1.
 *
 * Singleplayer: creates a client-side Alex-model companion and gives it a small
 * task system (follow, observe, gather guidance, chop-in-reach and structure planning).
 * Multiplayer: the companion body/tasks are disabled; Rose remains a chat-only assistant.
 *
 * Important: world-changing automation is deliberately restricted to singleplayer
 * and to normal client interaction APIs. It never sends fake automation packets to
 * a multiplayer server.
 */
public class McAiClient implements ClientModInitializer {
    private static McAiClient INSTANCE;
    private static final Random RANDOM = new Random();
    private static final String TAG = "[Rose] ";
    private static final UUID ROSE_UUID = UUID.fromString("e5beb6d7-19b7-43e4-92bc-ac3cf948f78c");
    private static final int ROSE_ENTITY_ID = -777777;

    private final Deque<String> conversation = new ArrayDeque<>();
    private long lastTalkTick = -1;
    private int talkCooldown;
    private int performanceCooldown;
    private int replyDelay;
    private String pendingReply;
    private String mood = "netral";
    private String lastPlayerMessage = "";

    private RemotePlayer rose;
    private boolean followEnabled = true;
    private String task = "none";
    private int taskCooldown;
    private String taskInfo = "";

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        ClientSendMessageEvents.CHAT.register(this::onPlayerChat);
    }

    private void onPlayerChat(String message) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return;
        String text = message == null ? "" : message.trim();
        if (text.isEmpty()) return;

        boolean singleplayer = client.hasSingleplayerServer();
        String lower = text.toLowerCase(Locale.ROOT);
        boolean addressed = lower.equals("rose") || lower.startsWith("rose ") || lower.startsWith("rose,")
                || lower.startsWith("rose:") || lower.startsWith("@rose")
                || lower.equals("ai") || lower.startsWith("ai ") || lower.startsWith("ai,")
                || lower.startsWith("ai:") || lower.startsWith("@ai") || lower.startsWith("assistant ");
        if (!singleplayer && !addressed) return;

        String clean = removeAddressPrefix(text);
        if (clean.isBlank()) clean = "hai";
        remember(clean);
        mood = detectMood(clean);
        handleTaskIntent(client, clean);
        pendingReply = answer(client, clean);
        replyDelay = 4;
    }

    private String removeAddressPrefix(String text) {
        String s = text.trim();
        String l = s.toLowerCase(Locale.ROOT);
        String[] prefixes = {"@rose", "rose:", "rose,", "rose ", "@ai", "ai:", "ai,", "ai ", "assistant "};
        for (String prefix : prefixes) if (l.startsWith(prefix)) return s.substring(prefix.length()).trim();
        if (l.equals("rose") || l.equals("ai")) return "";
        return s;
    }

    private void tick(Minecraft client) {
        if (client.player == null || client.level == null) return;
        long time = client.level.getGameTime();
        if (talkCooldown > 0) talkCooldown--;
        if (performanceCooldown > 0) performanceCooldown--;
        if (taskCooldown > 0) taskCooldown--;

        if (client.hasSingleplayerServer()) {
            ensureRose(client);
            if (rose != null) updateRose(client);
            runTask(client);
        } else if (rose != null) {
            removeRose(client);
        }

        if (replyDelay > 0) {
            replyDelay--;
            if (replyDelay == 0 && pendingReply != null) {
                say(client, pendingReply);
                pendingReply = null;
            }
        }

        if (lastTalkTick < 0) {
            lastTalkTick = time;
            talkCooldown = 3000;
            say(client, "Aku Rose. Di singleplayer aku bisa menemanimu sebagai companion Alex, mengikutimu, membaca dunia, dan menjalankan tugas yang kamu minta. Di multiplayer aku tetap chat-only.");
            return;
        }

        if (talkCooldown == 0 && time - lastTalkTick >= 3000) {
            lastTalkTick = time;
            talkCooldown = 3000 + RANDOM.nextInt(3000);
            say(client, contextualMessage(client));
        }

        if (performanceCooldown == 0 && time % 200 == 0) {
            int fps = client.getFps();
            if (fps > 0 && fps < 25) {
                performanceCooldown = 2400;
                say(client, "FPS sedang sekitar " + fps + ". Kalau kamu mau, aku bisa cek performanya.");
            }
        }
    }

    private void ensureRose(Minecraft client) {
        if (rose != null && rose.level() == client.level && !rose.isRemoved()) return;
        ClientLevel level = client.level;
        GameProfile profile = new GameProfile(ROSE_UUID, "Rose");
        rose = new RemotePlayer(level, profile);
        rose.setPos(client.player.getX() - 2.0, client.player.getY(), client.player.getZ() - 2.0);
        rose.setYRot(client.player.getYRot());
        rose.setXRot(client.player.getXRot());
        rose.setNoGravity(false);
        level.addEntity(rose);
    }

    private void removeRose(Minecraft client) {
        if (rose != null && client.level != null) {
            client.level.removeEntity(rose.getId(), Entity.RemovalReason.DISCARDED);
        }
        rose = null;
    }

    private void updateRose(Minecraft client) {
        if (!followEnabled || rose == null || client.player == null) return;
        Player p = client.player;
        double distance = rose.distanceTo(p);
        if (distance > 4.5) {
            // Keep Rose close without moving the real player. This is a visual client-side
            // companion; actual world actions are still performed through the local player.
            double angle = Math.toRadians(p.getYRot());
            double x = p.getX() + Math.sin(angle) * -2.5;
            double z = p.getZ() + Math.cos(angle) * -2.5;
            rose.setPos(x, p.getY(), z);
        }
        rose.setYRot(p.getYRot());
        rose.setYHeadRot(p.getYRot());
    }

    private void handleTaskIntent(Minecraft client, String text) {
        String l = normalize(text);
        if (!client.hasSingleplayerServer()) return;
        if (containsAny(l, "jangan ikut", "berhenti ikut", "stop follow", "berhenti mengikuti")) {
            followEnabled = false; task = "none"; return;
        }
        if (containsAny(l, "ikut aku", "ikuti aku", "ikuti saya", "follow aku", "follow saya", "temani aku")) {
            followEnabled = true; task = "none"; return;
        }
        if (containsAny(l, "nebang pohon", "tebang pohon", "cari kayu", "ambil kayu", "chop tree")) {
            task = "chop"; taskInfo = "mencari kayu yang bisa dijangkau"; taskCooldown = 0; return;
        }
        if (containsAny(l, "kumpulkan barang", "ambil barang", "ambil item", "cari item", "kumpulin")) {
            task = "gather"; taskInfo = "mencari item drop terdekat"; taskCooldown = 0; return;
        }
        if (containsAny(l, "masukkan ke chest", "taruh di chest", "simpan ke chest", "deposit ke chest")) {
            task = "deposit"; taskInfo = "mencari chest terdekat"; taskCooldown = 0; return;
        }
        if (containsAny(l, "buat rumah", "bangun rumah", "build house", "buat struktur", "bangun struktur")) {
            task = "plan"; taskInfo = "rencana rumah"; taskCooldown = 0; return;
        }
    }

    private void runTask(Minecraft client) {
        if (task.equals("none") || taskCooldown > 0 || client.player == null || client.level == null) return;
        taskCooldown = 40;
        switch (task) {
            case "chop" -> doChop(client);
            case "gather" -> doGather(client);
            case "deposit" -> doDeposit(client);
            case "plan" -> { task = "none"; say(client, housePlan(client, 7)); }
            default -> task = "none";
        }
    }

    private void doChop(Minecraft client) {
        Player p = client.player;
        BlockPos base = p.blockPosition();
        BlockPos target = null;
        double best = Double.MAX_VALUE;
        for (int x = -5; x <= 5; x++) for (int y = -3; y <= 5; y++) for (int z = -5; z <= 5; z++) {
            BlockPos pos = base.offset(x, y, z);
            String id = client.level.getBlockState(pos).getBlock().getName().getString().toLowerCase(Locale.ROOT);
            if ((id.contains("log") || id.contains("wood") || id.contains("stem")) && p.distanceToSqr(pos.getX()+0.5, pos.getY()+0.5, pos.getZ()+0.5) < best) {
                best = p.distanceToSqr(pos.getX()+0.5, pos.getY()+0.5, pos.getZ()+0.5);
                target = pos;
            }
        }
        if (target == null) {
            task = "none";
            say(client, "Aku tidak menemukan batang kayu yang bisa kujangkau. Dekatkan aku/dirimu ke pohon dulu.");
            return;
        }
        if (client.gameMode != null && client.gameMode.destroyBlock(target)) {
            taskInfo = "menebang " + target.getX() + "," + target.getY() + "," + target.getZ();
        } else {
            task = "none";
            say(client, "Aku menemukan kayu di " + target.getX() + "," + target.getY() + "," + target.getZ() + ", tetapi interaksi normal Minecraft tidak mengizinkanku memecahnya dari jarak itu.");
        }
    }

    private void doGather(Minecraft client) {
        Player p = client.player;
        ItemEntity nearest = null;
        double best = 32 * 32;
        for (Entity e : client.level.entitiesForRendering()) {
            if (e instanceof ItemEntity item && item.isAlive()) {
                double d = item.distanceToSqr(p);
                if (d < best) { best = d; nearest = item; }
            }
        }
        if (nearest == null) {
            task = "none";
            say(client, "Tidak ada item drop dalam radius 32 blok.");
            return;
        }
        String name = nearest.getItem().getHoverName().getString();
        double dx = nearest.getX() - p.getX();
        double dz = nearest.getZ() - p.getZ();
        say(client, "Item terdekat: " + name + " x" + nearest.getItem().getCount() + ". Arah " + directionFromVector(dx, dz) + ", sekitar " + Math.round(Math.sqrt(best)) + " blok. Mendekatlah dan item akan masuk ke inventory secara normal.");
        task = "none";
    }

    private void doDeposit(Minecraft client) {
        // Opening and rearranging a chest is intentionally not faked. We locate the nearest
        // chest and tell the player exactly where it is; the next version can automate the
        // normal container clicks once a chest is opened.
        BlockPos p = client.player.blockPosition();
        BlockPos nearest = findBlock(client, p, 12, "chest");
        if (nearest == null) { task = "none"; say(client, "Aku tidak menemukan chest dalam radius 12 blok."); return; }
        task = "none";
        say(client, "Chest terdekat ada di " + nearest.getX() + ", " + nearest.getY() + ", " + nearest.getZ() + ". Aku tidak akan memalsukan klik inventory; buka chest itu dan aku bisa membantumu menentukan item yang perlu disimpan.");
    }

    private BlockPos findBlock(Minecraft client, BlockPos center, int radius, String name) {
        BlockPos best = null; double dist = Double.MAX_VALUE;
        for (int x=-radius;x<=radius;x++) for(int y=-radius;y<=radius;y++) for(int z=-radius;z<=radius;z++) {
            BlockPos pos=center.offset(x,y,z);
            String n=client.level.getBlockState(pos).getBlock().getName().getString().toLowerCase(Locale.ROOT);
            if(n.contains(name) && center.distSqr(pos)<dist){dist=center.distSqr(pos);best=pos;}
        }
        return best;
    }

    private String answer(Minecraft client, String text) {
        String l = normalize(text);
        if (containsAny(l, "siapa kamu", "kamu siapa", "apa kamu"))
            return "Aku Rose, companion AI untuk Minecraft. Kepribadianku ramah, tenang, sedikit cerewet kalau perlu, dan fokus membantu. Di singleplayer aku bisa hadir sebagai avatar Alex dan mengikuti kamu; di multiplayer aku hanya menjadi assistant chat.";
        if (containsAny(l, "ikuti aku", "ikut aku", "temani aku", "follow aku"))
            return client.hasSingleplayerServer() ? "Siap. Aku akan tetap dekat denganmu." : "Di multiplayer aku tetap chat-only, jadi aku tidak akan menggerakkan avatar atau mengubah dunia server.";
        if (containsAny(l, "siapa di sekitar", "player sekitar", "pemain sekitar", "player dekat", "pemain dekat", "arah player", "arah pemain")) return nearbyPlayersReply(client);
        if (containsAny(l, "struktur", "rumah", "bangunan", "build", "bangunkan")) return housePlan(client, 7);
        if (containsAny(l, "tugas", "task", "sedang apa", "lagi ngapain")) return "Tugas Rose: " + task + (taskInfo.isBlank() ? "" : " — " + taskInfo) + ". Follow=" + (followEnabled ? "aktif" : "mati") + ".";
        if (containsAny(l, "koordinat", "coordinate", "coords", "posisi", "xyz", "x y z")) return coordinatesReply(client);
        if (containsAny(l, "armor", "armour", "baju besi", "zirah", "equipment")) return armorReply(client);
        if (containsAny(l, "inventory", "inventori", "barangku", "isi tas")) return inventoryReply(client);
        if (containsAny(l, "hp", "health", "darah", "nyawa")) return healthReply(client);
        if (containsAny(l, "lapar", "hunger", "makan", "kenyang")) return hungerReply(client);
        if (containsAny(l, "xp", "experience", "levelku", "level aku")) return xpReply(client);
        if (containsAny(l, "efek", "effect", "buff", "debuff")) return effectsReply(client);
        if (containsAny(l, "arah", "menghadap mana", "hadap mana", "facing")) return facingReply(client);
        if (containsAny(l, "siang atau malam", "sekarang malam", "sekarang siang", "jam berapa", "waktu sekarang")) return worldTimeReply(client);
        if (containsAny(l, "cuaca", "hujan", "petir")) return weatherReply(client);
        if (containsAny(l, "biome", "biom")) return biomeReply(client);
        if (containsAny(l, "dimensi", "dimension", "nether", "end")) return dimensionReply(client);
        if (containsAny(l, "lihat apa", "yang aku lihat", "blok apa", "target")) return lookingAtReply(client);
        if (containsAny(l, "mob sekitar", "ada mob", "entity sekitar", "entitas sekitar")) return nearbyReply(client);
        if (containsAny(l, "aman", "bahaya", "situasi")) return safetyReply(client);
        if (containsAny(l, "fps", "lag", "lemot", "performa", "ram", "render distance")) return performanceReply(client);
        if (containsAny(l, "perasaanku", "perasaan aku", "mood aku", "aku merasa")) return moodReply();
        if (!"netral".equals(mood)) return moodAwareReply();
        if (containsAny(l, "halo", "hai", "hi", "hey")) return "Hai. Aku di sini. Mau ngobrol, cek keadaanmu, mencari resource, atau merencanakan bangunan?";
        if (containsAny(l, "terima kasih", "makasih", "thanks")) return "Sama-sama. Aku senang membantu.";
        return "Aku memahami pertanyaanmu sebagai: '" + shorten(text, 100) + "'. Aku bisa membaca state Minecraft dan menjalankan beberapa tugas singleplayer. Kalau ingin aksi, bilang misalnya: 'ikuti aku', 'tebang pohon', 'kumpulkan barang', 'taruh di chest', atau 'buat rencana rumah'.";
    }

    private String nearbyPlayersReply(Minecraft client) {
        List<String> out = new ArrayList<>();
        for (Player p : client.level.players()) {
            if (p == client.player || p == rose) continue;
            double dx=p.getX()-client.player.getX(), dz=p.getZ()-client.player.getZ();
            out.add(p.getGameProfile().name()+" — "+Math.round(Math.sqrt(dx*dx+dz*dz))+" blok, arah "+directionFromVector(dx,dz)+" (X "+Math.round(p.getX())+", Y "+Math.round(p.getY())+", Z "+Math.round(p.getZ())+")");
        }
        return out.isEmpty()?"Tidak ada pemain lain yang terlihat saat ini.":"Pemain yang terlihat: "+String.join("; ",out)+".";
    }

    private String directionFromVector(double dx,double dz){
        double angle=Math.toDegrees(Math.atan2(-dx,dz));
        if(angle<0)angle+=360;
        String[] dirs={"selatan","barat daya","barat","barat laut","utara","timur laut","timur","tenggara"};
        return dirs[(int)Math.round(angle/45.0)%8];
    }

    private String coordinatesReply(Minecraft client){Player p=client.player;return String.format(Locale.ROOT,"Koordinatmu: X %.1f, Y %.1f, Z %.1f (blok %d, %d, %d).",p.getX(),p.getY(),p.getZ(),p.blockPosition().getX(),p.blockPosition().getY(),p.blockPosition().getZ());}
    private String armorReply(Minecraft c){Player p=c.player;return "Armor: kepala="+itemLong(p.getItemBySlot(EquipmentSlot.HEAD))+", dada="+itemLong(p.getItemBySlot(EquipmentSlot.CHEST))+", kaki="+itemLong(p.getItemBySlot(EquipmentSlot.LEGS))+", sepatu="+itemLong(p.getItemBySlot(EquipmentSlot.FEET))+".";}
    private String inventoryReply(Minecraft c){Player p=c.player;List<String> a=new ArrayList<>();for(int i=0;i<p.getInventory().getContainerSize();i++){ItemStack s=p.getInventory().getItem(i);if(!s.isEmpty())a.add(itemLong(s));}if(a.isEmpty())return"Inventory kosong.";return"Inventory terisi "+a.size()+" slot: "+String.join(", ",a.subList(0,Math.min(16,a.size())))+(a.size()>16?" ...":"")+".";}
    private String healthReply(Minecraft c){Player p=c.player;return String.format(Locale.ROOT,"HP %.1f/%.1f, armor %.1f, absorption %.1f.",p.getHealth(),p.getMaxHealth(),p.getArmorValue(),p.getAbsorptionAmount());}
    private String hungerReply(Minecraft c){var f=c.player.getFoodData();return"Hunger "+f.getFoodLevel()+"/20, saturation "+String.format(Locale.ROOT,"%.1f",f.getSaturationLevel())+".";}
    private String xpReply(Minecraft c){Player p=c.player;return String.format(Locale.ROOT,"Level XP %d, progress %.1f%%, total %d.",p.experienceLevel,p.experienceProgress*100,p.totalExperience);}
    private String effectsReply(Minecraft c){List<String>a=new ArrayList<>();for(var e:c.player.getActiveEffects())a.add(e.getEffect().value().getDisplayName().getString()+" x"+(e.getAmplifier()+1)+" ("+Math.max(0,e.getDuration()/20)+"s)");return a.isEmpty()?"Tidak ada effect aktif.":"Effect aktif: "+String.join(", ",a)+".";}
    private String facingReply(Minecraft c){return"Kamu menghadap "+c.player.getDirection().getName()+" (yaw "+String.format(Locale.ROOT,"%.1f",c.player.getYRot())+"°).";}
    private String worldTimeReply(Minecraft c){long t=Math.floorMod(c.level.getOverworldClockTime(),24000L);int h=(int)(((t/1000L)+6)%24),m=(int)((t%1000L)*60/1000L);String label=h>=5&&h<11?"pagi":h>=11&&h<15?"siang":h>=15&&h<18?"sore":"malam";return String.format(Locale.ROOT,"Jam dunia Minecraft %02d:%02d (%s).",h,m,label);}
    private String weatherReply(Minecraft c){return c.level.isThundering()?"Badai petir.":c.level.isRaining()?"Hujan.":"Cerah.";}
    private String biomeReply(Minecraft c){return"Biome: "+c.level.getBiome(c.player.blockPosition()).getRegisteredName()+".";}
    private String dimensionReply(Minecraft c){return"Dimension: "+c.level.dimension().location()+".";}
    private String lookingAtReply(Minecraft c){if(c.hitResult==null)return"Tidak ada target.";return"Target yang kamu lihat: "+c.hitResult.getType()+".";}
    private String nearbyReply(Minecraft c){int n=0;double d0=999;String name="tidak ada";for(Entity e:c.level.entitiesForRendering()){if(e==c.player||e==rose)continue;double d=e.distanceTo(c.player);if(d<=32){n++;if(d<d0){d0=d;name=e.getName().getString();}}}return n==0?"Tidak ada entity lain dalam 32 blok.":"Ada "+n+" entity dalam 32 blok. Terdekat: "+name+" sekitar "+Math.round(d0)+" blok.";}
    private String safetyReply(Minecraft c){if(c.player.getHealth()<=6)return"HP-mu rendah. Prioritas: cari tempat aman dan pulihkan HP.";if(c.player.getFoodData().getFoodLevel()<=6)return"Kamu lapar. Cari makanan.";return"Dari state dasar yang kulihat, tidak ada bahaya besar yang terdeteksi.";}
    private String performanceReply(Minecraft c){return"FPS "+c.getFps()+", RAM "+((Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory())/1048576)+" MB, render distance "+c.options.getEffectiveRenderDistance()+" chunk.";}
    private String housePlan(Minecraft c,int size){int x=c.player.blockPosition().getX(),y=c.player.blockPosition().getY(),z=c.player.blockPosition().getZ();return"Rencana rumah "+size+"x"+size+": fondasi di sekitar X="+x+", Y="+y+", Z="+z+"; dinding tinggi 4 blok; pintu 1 di sisi depan; jendela di dua sisi; atap bertingkat; interior: chest, crafting table, furnace, bed. Aku bisa memakai rencana ini sebagai target build singleplayer, tetapi aku tidak akan menempatkan blok secara diam-diam tanpa resource dan interaksi yang valid.";}
    private String contextualMessage(Minecraft c){if(c.player.getHealth()<=6)return"HP-mu rendah. Kita cari tempat aman dulu?";if(c.player.getFoodData().getFoodLevel()<=6)return"Kamu mulai lapar. Mau cari makanan?";if(c.hasSingleplayerServer()&&followEnabled)return"Aku masih di dekatmu. Kalau ada tugas, panggil aku dengan namaku.";return"Aku masih mengamati dunia. Kalau butuh aku, panggil 'Rose'.";}
    private String moodAwareReply(){return switch(mood){case"sedih"->"Aku menangkap kamu mungkin sedang sedih dari tulisanmu. Aku bisa mendengarkan kalau kamu mau cerita.";case"marah"->"Kedengarannya kamu sedang kesal. Kita bisa membahasnya pelan-pelan.";case"cemas"->"Aku menangkap ada kekhawatiran. Kita bisa pecah masalahnya satu per satu.";case"lelah"->"Kedengarannya kamu lelah. Kita bisa santai dulu.";case"bingung"->"Kalau kamu bingung, kita pecah pertanyaannya menjadi langkah kecil.";case"senang"->"Kedengarannya kamu sedang senang. Ceritakan apa yang terjadi.";default->"Aku mendengarkan.";};}
    private String moodReply(){return"Mood yang kutangkap dari bahasa terakhirmu: "+mood+". Ini hanya perkiraan dari kata-kata, bukan pembacaan pikiran.";}
    private String detectMood(String t){String l=normalize(t);if(containsAny(l,"sedih","nangis","kecewa","hancur"))return"sedih";if(containsAny(l,"marah","kesal","kesel","jengkel"))return"marah";if(containsAny(l,"cemas","khawatir","takut","panik"))return"cemas";if(containsAny(l,"capek","lelah","letih","ngantuk"))return"lelah";if(containsAny(l,"bingung","gak ngerti","tidak ngerti","susah"))return"bingung";if(containsAny(l,"senang","bahagia","gembira","seru","keren","mantap"))return"senang";return"netral";}
    private void remember(String m){lastPlayerMessage=m;conversation.addLast(m);while(conversation.size()>16)conversation.removeFirst();}
    private String itemLong(ItemStack s){if(s.isEmpty())return"kosong";String n=s.getHoverName().getString()+" x"+s.getCount();if(s.isDamageableItem())n+=" (durability "+(s.getMaxDamage()-s.getDamageValue())+"/"+s.getMaxDamage()+")";return n;}
    private String normalize(String s){return s.toLowerCase(Locale.ROOT).replaceAll("\\s+"," ").trim();}
    private boolean containsAny(String t,String...w){for(String s:w)if(t.contains(s))return true;return false;}
    private String shorten(String s,int n){return s==null?"":s.length()<=n?s:s.substring(0,n-3)+"...";}

    public static void chat(Minecraft client,String message){if(INSTANCE==null||client.player==null||message==null||message.isBlank())return;INSTANCE.remember(message.trim());INSTANCE.mood=INSTANCE.detectMood(message);INSTANCE.handleTaskIntent(client,message);INSTANCE.pendingReply=INSTANCE.answer(client,message.trim());INSTANCE.replyDelay=2;}
    public static void say(Minecraft client,String message){if(client.player!=null)client.player.sendSystemMessage(Component.literal(TAG+message));}
    public static void mood(Minecraft client){if(INSTANCE!=null)say(client,INSTANCE.moodReply());}
    public static void performance(Minecraft client){if(INSTANCE!=null)say(client,INSTANCE.performanceReply(client));}
    public static void companion(Minecraft client){if(INSTANCE==null||client.player==null)return;if(!client.hasSingleplayerServer()){say(client,"Companion avatar hanya aktif di singleplayer. Di multiplayer aku chat-only.");return;}INSTANCE.followEnabled=true;INSTANCE.ensureRose(client);say(client,"Aku sudah muncul sebagai Rose dan akan mengikutimu.");}
    public static void follow(Minecraft client){if(INSTANCE==null)return;INSTANCE.followEnabled=true;say(client,"Mode mengikuti aktif.");}
    public static void stop(Minecraft client){if(INSTANCE==null)return;INSTANCE.followEnabled=false;INSTANCE.task="none";say(client,"Aku berhenti mengikuti dan menghentikan tugas aktif.");}
    public static void task(Minecraft client,String t){if(INSTANCE==null)return;INSTANCE.handleTaskIntent(client,t);say(client,"Tugas diterima: "+INSTANCE.task+" — "+(INSTANCE.taskInfo.isBlank()?"siap":INSTANCE.taskInfo)+".");}
}
