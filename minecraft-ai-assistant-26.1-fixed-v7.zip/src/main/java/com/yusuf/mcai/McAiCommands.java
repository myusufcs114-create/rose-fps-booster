package com.yusuf.mcai;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.client.Minecraft;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.literal;

public class McAiCommands implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(literal("ai")
                .then(literal("companion").executes(ctx -> { McAiClient.companion(Minecraft.getInstance()); return 1; }))
                .then(literal("follow").executes(ctx -> { McAiClient.follow(Minecraft.getInstance()); return 1; }))
                .then(literal("stop").executes(ctx -> { McAiClient.stop(Minecraft.getInstance()); return 1; }))
                .then(literal("status").executes(ctx -> { McAiClient.say(Minecraft.getInstance(), "Rose aktif. Singleplayer=" + Minecraft.getInstance().hasSingleplayerServer() + ". Gunakan: /ai companion, /ai follow, /ai stop, /ai task <tugas>, /ai players, /ai chat <pesan>. Di multiplayer aku chat-only."); return 1; }))
                .then(literal("performance").executes(ctx -> { McAiClient.performance(Minecraft.getInstance()); return 1; }))
                .then(literal("mood").executes(ctx -> { McAiClient.mood(Minecraft.getInstance()); return 1; }))
                .then(literal("players").executes(ctx -> { McAiClient.chat(Minecraft.getInstance(), "siapa player sekitar dan arah mereka"); return 1; }))
                .then(literal("task").then(argument("task", StringArgumentType.greedyString()).executes(ctx -> { McAiClient.task(Minecraft.getInstance(), StringArgumentType.getString(ctx, "task")); return 1; })))
                .then(literal("chat").then(argument("message", StringArgumentType.greedyString()).executes(ctx -> { McAiClient.chat(Minecraft.getInstance(), StringArgumentType.getString(ctx, "message")); return 1; })))
        ));
    }
}
