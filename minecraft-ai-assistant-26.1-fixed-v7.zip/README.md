# Rose AI Assistant — v1.3.0 / Minecraft 26.1

Rose is a client-side Fabric companion for Minecraft 26.1.

## Personality
Rose uses a friendly, calm, feminine-coded assistant persona inspired by a game-system/JARVIS style companion. This is a game character personality, not a romantic roleplay system.

## Singleplayer
- Spawns a client-side Alex-style player avatar named Rose.
- Follows the player and can be stopped/resumed.
- Reads coordinates, armor, inventory, health, hunger, XP, effects, biome, time, weather, dimension, target, entities and performance.
- Finds nearby dropped items and reports direction/distance.
- Finds nearby chests and reports their location.
- Can perform limited normal block-breaking assistance (for example, chopping a reachable log) using the player's normal interaction manager.
- Can create structure plans such as a 7x7 starter house and explain required layout/resources.
- Has short conversation memory and mood estimation.

## Multiplayer
- The avatar and world-changing task automation are disabled.
- Rose remains a chat-only assistant and only answers when addressed (Rose/AI/@Rose).
- It can list visible players, coordinates and relative directions.
- It never attempts to inject fake world-editing actions into multiplayer servers.

## Commands
- `/ai companion`
- `/ai follow`
- `/ai stop`
- `/ai status`
- `/ai players`
- `/ai task <task>`
- `/ai chat <message>`
- `/ai mood`
- `/ai performance`

Natural language examples:
- `Rose, ikuti aku`
- `Rose, tebang pohon`
- `Rose, kumpulkan barang`
- `Rose, taruh di chest`
- `Rose, buat rumah`
- `Rose, siapa player di sekitar dan arahnya?`
