package com.rose.fpsboost;

import net.fabricmc.api.ClientModInitializer;

/**
 * Rose Performance Engine v2.
 *
 * The mod is intentionally dependency-light so it can complement Sodium,
 * Iris, ImmediatelyFast and MobileGlues instead of replacing their renderer.
 */
public final class RoseFpsBooster implements ClientModInitializer {
    public static final PerformanceController CONTROLLER = new PerformanceController();

    @Override
    public void onInitializeClient() {
        CONTROLLER.onClientInit();
    }
}
