package com.rose.fpsboost;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Rose Performance Engine v2.
 *
 * It cannot add physical RAM or replace a CPU/GPU. Instead it acts as a
 * workload governor: it measures frame/tick/memory pressure, makes decisions
 * on a worker thread, and applies safe client options on Minecraft's thread.
 *
 * The "1 TB memory" feature is a disk-cache ceiling, not fake RAM. The cache
 * is sparse/organic: it only consumes storage for data actually written.
 */
public final class PerformanceController {
    private static final int TARGET_FPS = 200;
    private static final int START_RENDER_DISTANCE = 16;
    private static final int MIN_RENDER_DISTANCE = 6;
    private static final int MAX_RENDER_DISTANCE = 20;

    private static final int START_SIMULATION_DISTANCE = 6;
    private static final int MIN_SIMULATION_DISTANCE = 4;
    private static final int MAX_SIMULATION_DISTANCE = 8;

    private static final double START_ENTITY_DISTANCE = 0.75D;
    private static final double MIN_ENTITY_DISTANCE = 0.35D;
    private static final double MAX_ENTITY_DISTANCE = 1.0D;

    // 1 TiB ceiling for the optional persistent cache. This does NOT reserve 1 TiB.
    private static final long CACHE_LIMIT_BYTES = 1L << 40;

    private static final long SAMPLE_INTERVAL_MS = 1000L;
    private static final long DECISION_INTERVAL_MS = 2000L;
    private static final long GC_COOLDOWN_MS = 30_000L;

    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Rose-Performance-Worker");
        t.setDaemon(true);
        return t;
    });
    private final AtomicBoolean decisionPending = new AtomicBoolean();

    private volatile Decision pendingDecision;
    private Object minecraft;
    private Path cacheDirectory;
    private int lastRenderDistance = START_RENDER_DISTANCE;
    private int lastSimulationDistance = START_SIMULATION_DISTANCE;
    private double lastEntityDistance = START_ENTITY_DISTANCE;
    private long lastSampleNanos;
    private long lastDecisionNanos;
    private long lastGcNanos;
    private long previousTickNanos;
    private boolean initialized;
    private boolean shutdown;

    // Smoothed metrics avoid reacting to one bad frame.
    private double smoothFps = 60.0D;
    private double smoothTickMs = 50.0D;
    private double smoothMemoryPressure = 0.0D;
    private int pressureSamples;
    private int headroomSamples;

    public void onClientInit() {
        initialized = false;
        shutdown = false;
        lastSampleNanos = 0L;
        lastDecisionNanos = 0L;
        previousTickNanos = 0L;
    }

    public void tick(Object client) {
        if (shutdown) return;

        long now = System.nanoTime();
        if (!initialized) {
            minecraft = client;
            cacheDirectory = resolveCacheDirectory(client);
            applyBaseline();
            writeCacheMetadata();
            initialized = true;
            previousTickNanos = now;
            lastSampleNanos = now;
            lastDecisionNanos = now;
            return;
        }

        long tickDelta = now - previousTickNanos;
        previousTickNanos = now;
        double tickMs = tickDelta / 1_000_000.0D;
        if (tickMs > 0.0D && tickMs < 2000.0D) {
            smoothTickMs = ema(smoothTickMs, tickMs, 0.18D);
        }

        // Apply the last worker-thread decision on Minecraft's thread.
        Decision decision = pendingDecision;
        if (decision != null) {
            pendingDecision = null;
            applyDecision(decision);
        }

        if (now - lastSampleNanos < SAMPLE_INTERVAL_MS * 1_000_000L) return;
        lastSampleNanos = now;

        int fps = readFps();
        if (fps > 0) smoothFps = ema(smoothFps, fps, 0.22D);

        MemorySnapshot memory = readMemory();
        smoothMemoryPressure = ema(smoothMemoryPressure, memory.pressure(), 0.20D);

        boolean underPressure = smoothFps < 45.0D || smoothTickMs > 85.0D || smoothMemoryPressure > 0.86D;
        boolean hasHeadroom = smoothFps >= 150.0D && smoothTickMs < 45.0D && smoothMemoryPressure < 0.68D;

        if (underPressure) {
            pressureSamples++;
            headroomSamples = 0;
        } else if (hasHeadroom) {
            headroomSamples++;
            pressureSamples = 0;
        } else {
            pressureSamples = Math.max(0, pressureSamples - 1);
            headroomSamples = Math.max(0, headroomSamples - 1);
        }

        if (now - lastDecisionNanos >= DECISION_INTERVAL_MS * 1_000_000L
                && decisionPending.compareAndSet(false, true)) {
            lastDecisionNanos = now;
            Snapshot snapshot = new Snapshot(
                    smoothFps,
                    smoothTickMs,
                    smoothMemoryPressure,
                    lastRenderDistance,
                    lastSimulationDistance,
                    lastEntityDistance,
                    pressureSamples,
                    headroomSamples);
            worker.submit(() -> makeDecision(snapshot));
        }

        // Avoid calling System.gc() routinely. Only request it after sustained
        // memory pressure and with a long cooldown, because GC itself can stutter.
        if (smoothMemoryPressure > 0.93D
                && now - lastGcNanos > GC_COOLDOWN_MS * 1_000_000L) {
            lastGcNanos = now;
            System.gc();
        }
    }

    private void makeDecision(Snapshot s) {
        try {
            Decision d = null;

            if (s.pressureSamples() >= 2) {
                int render = Math.max(MIN_RENDER_DISTANCE, s.renderDistance() - 2);
                int simulation = Math.max(MIN_SIMULATION_DISTANCE, s.simulationDistance() - 1);
                double entities = Math.max(MIN_ENTITY_DISTANCE, s.entityDistance() - 0.10D);
                d = new Decision(render, simulation, entities);
            } else if (s.headroomSamples() >= 4) {
                int render = Math.min(MAX_RENDER_DISTANCE, s.renderDistance() + 1);
                int simulation = Math.min(MAX_SIMULATION_DISTANCE, s.simulationDistance() + 1);
                double entities = Math.min(MAX_ENTITY_DISTANCE, s.entityDistance() + 0.05D);
                d = new Decision(render, simulation, entities);
            }

            if (d != null) pendingDecision = d;
        } finally {
            decisionPending.set(false);
        }
    }

    private void applyBaseline() {
        try {
            Object options = getOptions();
            setOption(options, "renderDistance", START_RENDER_DISTANCE);
            setOption(options, "simulationDistance", START_SIMULATION_DISTANCE);
            setOption(options, "maxFps", TARGET_FPS);
            setOption(options, "enableVsync", false);
            setOptionIfPresent(options, "entityDistanceScaling", START_ENTITY_DISTANCE);
            lastRenderDistance = START_RENDER_DISTANCE;
            lastSimulationDistance = START_SIMULATION_DISTANCE;
            lastEntityDistance = START_ENTITY_DISTANCE;
        } catch (Throwable ignored) {
            // Never crash Minecraft if a loader/renderer changes an option API.
        }
    }

    private void applyDecision(Decision d) {
        try {
            Object options = getOptions();
            if (d.renderDistance() != lastRenderDistance) {
                setOption(options, "renderDistance", d.renderDistance());
                lastRenderDistance = d.renderDistance();
            }
            if (d.simulationDistance() != lastSimulationDistance) {
                setOption(options, "simulationDistance", d.simulationDistance());
                lastSimulationDistance = d.simulationDistance();
            }
            if (Math.abs(d.entityDistance() - lastEntityDistance) > 0.001D) {
                setOptionIfPresent(options, "entityDistanceScaling", d.entityDistance());
                lastEntityDistance = d.entityDistance();
            }
            writeCacheMetadata();
        } catch (Throwable ignored) {
        }
    }

    private int readFps() {
        try {
            Method m = minecraft.getClass().getMethod("getFps");
            Object value = m.invoke(minecraft);
            if (value instanceof Number n) return n.intValue();
        } catch (Throwable ignored) {
        }
        return 0;
    }

    private MemorySnapshot readMemory() {
        Runtime r = Runtime.getRuntime();
        long max = r.maxMemory();
        long used = r.totalMemory() - r.freeMemory();
        double pressure = max > 0L ? Math.min(1.0D, (double) used / (double) max) : 0.0D;
        return new MemorySnapshot(used, max, pressure);
    }

    private Object getOptions() throws Exception {
        Field f = findField(minecraft.getClass(), "options");
        if (f == null) throw new NoSuchFieldException("options");
        f.setAccessible(true);
        return f.get(minecraft);
    }

    private static void setOption(Object options, String methodName, Object value) throws Exception {
        Method getter = options.getClass().getMethod(methodName);
        Object option = getter.invoke(options);
        invokeOptionSetter(option, value);
    }

    private static void setOptionIfPresent(Object options, String methodName, Object value) {
        try {
            setOption(options, methodName, value);
        } catch (Throwable ignored) {
        }
    }

    private static void invokeOptionSetter(Object option, Object value) throws Exception {
        for (Method m : option.getClass().getMethods()) {
            if (!m.getName().equals("set") || m.getParameterCount() != 1) continue;
            Class<?> parameter = m.getParameterTypes()[0];
            Object converted = convertValue(parameter, value);
            if (converted != null || !parameter.isPrimitive()) {
                m.invoke(option, converted);
                return;
            }
        }
        throw new NoSuchMethodException("Option.set");
    }

    private static Object convertValue(Class<?> target, Object value) {
        if (value == null) return null;
        if (target.isInstance(value)) return value;
        if (target == int.class || target == Integer.class) {
            return value instanceof Number n ? n.intValue() : null;
        }
        if (target == double.class || target == Double.class) {
            return value instanceof Number n ? n.doubleValue() : null;
        }
        if (target == float.class || target == Float.class) {
            return value instanceof Number n ? n.floatValue() : null;
        }
        if (target == long.class || target == Long.class) {
            return value instanceof Number n ? n.longValue() : null;
        }
        if (target == boolean.class || target == Boolean.class) {
            return value instanceof Boolean b ? b : null;
        }
        return null;
    }

    private static Field findField(Class<?> type, String name) {
        Class<?> c = type;
        while (c != null) {
            try {
                return c.getDeclaredField(name);
            } catch (NoSuchFieldException ignored) {
                c = c.getSuperclass();
            }
        }
        return null;
    }

    private Path resolveCacheDirectory(Object client) {
        try {
            Method m = client.getClass().getMethod("gameDirectory");
            Object value = m.invoke(client);
            if (value instanceof java.io.File f) {
                Path dir = f.toPath().resolve("rose-performance-cache");
                Files.createDirectories(dir);
                return dir;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private void writeCacheMetadata() {
        if (cacheDirectory == null) return;
        worker.submit(() -> {
            try {
                Files.createDirectories(cacheDirectory);
                Path meta = cacheDirectory.resolve("profile.properties");
                String text = "Rose Performance Engine v2\n"
                        + "cacheLimitBytes=" + CACHE_LIMIT_BYTES + "\n"
                        + "cacheLimitTiB=1\n"
                        + "renderDistance=" + lastRenderDistance + "\n"
                        + "simulationDistance=" + lastSimulationDistance + "\n"
                        + String.format(Locale.ROOT, "entityDistance=%.2f\n", lastEntityDistance)
                        + "note=Disk cache is not RAM and grows only when real cache data is written.\n";
                Files.writeString(meta, text, StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING,
                        StandardOpenOption.WRITE);
            } catch (IOException ignored) {
            }
        });
    }

    public void shutdown() {
        if (shutdown) return;
        shutdown = true;
        worker.shutdownNow();
    }

    private static double ema(double oldValue, double newValue, double alpha) {
        return oldValue + (newValue - oldValue) * alpha;
    }

    private record Snapshot(
            double fps,
            double tickMs,
            double memoryPressure,
            int renderDistance,
            int simulationDistance,
            double entityDistance,
            int pressureSamples,
            int headroomSamples) {}

    private record Decision(int renderDistance, int simulationDistance, double entityDistance) {}

    private record MemorySnapshot(long used, long max, double pressure) {}
}
