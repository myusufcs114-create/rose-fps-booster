# Rose Performance Engine v2 — Minecraft 26.1

Rose Performance Engine v2 is a lightweight client-side performance governor designed to complement Sodium, Iris, ImmediatelyFast and MobileGlues.

## What v2 does

- **CPU Assistant:** makes performance decisions on a small daemon worker thread so option analysis does not add work to the Minecraft tick.
- **GPU Assistant:** dynamically adjusts render distance and entity-distance scaling from sustained frame/tick pressure.
- **Adaptive Governor:** reacts to FPS, tick interval and Java heap pressure instead of chasing every single frame.
- **Memory Assistant:** monitors Java heap usage and reduces client workload before memory pressure becomes severe.
- **Anti-OOM behavior:** at very high heap pressure, Rose reduces workload and only requests GC after a long cooldown to avoid constant GC stutter.
- **1 TiB Virtual Cache ceiling:** the engine supports a persistent cache budget of **1 TiB** (1024 GiB). It does **not** create 1 TiB of RAM and does not reserve 1 TiB of storage at startup. Storage is consumed only by real cache data written by future cache modules.
- **Safe compatibility:** reflection is used for options so a changed Minecraft/renderer option API should fail gracefully instead of crashing the client.

## Important limitation

A Fabric mod cannot physically add RAM, replace the phone's CPU/GPU, or make a 60 Hz/limited GPU produce 200 real frames per second. Rose instead reduces unnecessary client workload and adapts quality to the hardware available.

## Recommended stack

Minecraft 26.1 + Fabric Loader 0.19.1 + Sodium + ImmediatelyFast + MobileGlues.

Iris should remain disabled unless shaders are intentionally being used. Avoid stacking other mods that repeatedly force invalid graphics options.

## Build

Use JDK 25. The GitHub Actions workflow can build this project on a phone without a PC.

Output:

`build/libs/rose-fps-booster-2.0.0.jar`
