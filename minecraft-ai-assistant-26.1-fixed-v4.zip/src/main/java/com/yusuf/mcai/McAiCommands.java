package com.yusuf.mcai;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.client.Minecraft;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.literal;

public class McAiCommands implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(literal("ai")
                    .then(literal("performance").executes(ctx -> {
                        McAiClient.performance(Minecraft.getInstance());
                        return 1;
                    }))
                    .then(literal("status").executes(ctx -> {
                        McAiClient.say(Minecraft.getInstance(),
                                "Aku aktif. Gunakan /ai performance untuk laporan FPS/RAM/entity.");
                        return 1;
                    }))
                    .then(literal("quiet").executes(ctx -> {
                        McAiClient.say(Minecraft.getInstance(),
                                "Mode quiet belum mematikan AI secara permanen pada versi awal ini.");
                        return 1;
                    })));
        });
    }
}
