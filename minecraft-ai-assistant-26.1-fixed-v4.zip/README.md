# Minecraft AI Assistant — Minecraft 26.1

Client-side Fabric mod for Minecraft 26.1.

## Build

Requires Java 25 and Gradle 9.4.0.

The GitHub Actions workflow builds the project and uploads the JAR as an artifact.

## Commands

- `/ai status`
- `/ai performance`
- `/ai quiet`

Minecraft 26.1 uses the non-remapping Fabric Loom setup and official Mojang names.
